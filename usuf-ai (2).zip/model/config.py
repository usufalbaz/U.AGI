"""
USUF AI - Transformer Model Configuration
Parses and validates model hyperparameters from YAML configuration.
Includes exact parameter calculation formula for USUF-0.01 through USUF-1.
"""
import os
from dataclasses import dataclass
from typing import Optional, Dict, Any

try:
    import yaml
except ImportError:
    yaml = None


@dataclass
class USUFModelConfig:
    name: str = "USUF-0.01"
    vocab_size: int = 32000
    context_length: int = 256
    hidden_size: int = 192
    num_layers: int = 4
    num_heads: int = 6
    head_dim: int = 32
    intermediate_size: int = 512
    norm_type: str = "rmsnorm"
    norm_eps: float = 1e-5
    activation: str = "swiglu"
    positional_embedding: str = "rope"
    rope_theta: float = 10000.0
    dropout: float = 0.1
    tie_word_embeddings: bool = True
    bias: bool = False

    def __post_init__(self):
        if self.head_dim * self.num_heads != self.hidden_size:
            raise ValueError(
                f"hidden_size ({self.hidden_size}) must equal num_heads ({self.num_heads}) "
                f"* head_dim ({self.head_dim})"
            )

    def estimate_parameter_count(self) -> Dict[str, int]:
        """Calculates precise parameter count for architecture verification."""
        # 1. Token Embeddings
        embedding_params = self.vocab_size * self.hidden_size
        
        # 2. Transformer Blocks
        # Attention: Q, K, V projections + Output projection
        attn_params_per_layer = (4 * self.hidden_size * self.hidden_size)
        if self.bias:
            attn_params_per_layer += 4 * self.hidden_size
            
        # SwiGLU MLP: Gate, Up, Down projections
        mlp_params_per_layer = (3 * self.hidden_size * self.intermediate_size)
        if self.bias:
            mlp_params_per_layer += (2 * self.intermediate_size + self.hidden_size)
            
        # 2 Normalization layers per block
        norm_params_per_layer = 2 * self.hidden_size
        
        per_layer_params = attn_params_per_layer + mlp_params_per_layer + norm_params_per_layer
        total_layers_params = self.num_layers * per_layer_params
        
        # 3. Final Norm
        final_norm_params = self.hidden_size
        
        # 4. LM Head (if not tied to embedding)
        lm_head_params = 0 if self.tie_word_embeddings else (self.hidden_size * self.vocab_size)
        
        total_params = embedding_params + total_layers_params + final_norm_params + lm_head_params

        return {
            "embedding_params": embedding_params,
            "per_layer_params": per_layer_params,
            "transformer_layers_params": total_layers_params,
            "final_norm_params": final_norm_params,
            "lm_head_params": lm_head_params,
            "total_params": total_params,
            "total_millions": round(total_params / 1_000_000, 2),
        }


def get_model_config(config_path: str = "configs/model.yaml", variant: Optional[str] = None) -> USUFModelConfig:
    """Loads a specific model variant from configs/model.yaml."""
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found at: {config_path}")

    if yaml is not None:
        with open(config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        active_var = variant or data.get("active_variant", "usuf_0_01")
        if active_var not in data["models"]:
            raise KeyError(f"Variant '{active_var}' not found in {config_path}. Available: {list(data['models'].keys())}")
        cfg_dict = data["models"][active_var]
    else:
        # Fallback simple parser if running in minimal container without pyyaml
        active_var = variant or "usuf_0_01"
        if active_var == "usuf_0_01":
            cfg_dict = {"name": "USUF-0.01", "vocab_size": 32000, "context_length": 256, "hidden_size": 192, "num_layers": 4, "num_heads": 6, "head_dim": 32, "intermediate_size": 512}
        elif active_var == "usuf_1":
            cfg_dict = {"name": "USUF-1", "vocab_size": 32000, "context_length": 2048, "hidden_size": 768, "num_layers": 24, "num_heads": 12, "head_dim": 64, "intermediate_size": 2048}
        else:
            cfg_dict = {"name": active_var, "vocab_size": 32000, "context_length": 256, "hidden_size": 192, "num_layers": 4, "num_heads": 6, "head_dim": 32, "intermediate_size": 512}
    return USUFModelConfig(
        name=cfg_dict.get("name", active_var),
        vocab_size=cfg_dict.get("vocab_size", 32000),
        context_length=cfg_dict.get("context_length", 256),
        hidden_size=cfg_dict.get("hidden_size", 192),
        num_layers=cfg_dict.get("num_layers", 4),
        num_heads=cfg_dict.get("num_heads", 6),
        head_dim=cfg_dict.get("head_dim", 32),
        intermediate_size=cfg_dict.get("intermediate_size", 512),
        norm_type=cfg_dict.get("norm_type", "rmsnorm"),
        norm_eps=float(cfg_dict.get("norm_eps", 1e-5)),
        activation=cfg_dict.get("activation", "swiglu"),
        positional_embedding=cfg_dict.get("positional_embedding", "rope"),
        rope_theta=float(cfg_dict.get("rope_theta", 10000.0)),
        dropout=float(cfg_dict.get("dropout", 0.1)),
        tie_word_embeddings=bool(cfg_dict.get("tie_word_embeddings", True)),
        bias=bool(cfg_dict.get("bias", False)),
    )
