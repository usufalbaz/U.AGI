"""
USUF AI Model Package
Custom Decoder-Only Transformer Architecture
"""
from .config import USUFModelConfig, get_model_config

__all__ = ["USUFModelConfig", "get_model_config"]
