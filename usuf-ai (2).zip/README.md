# USUF AI: Training a Large Language Model From Scratch

<p align="center">
  <b>Lead Developer & Architecture: Engineer Yousuf Albaz</b><br>
  <i>A scientific, transparent, zero-pretrained-weight LLM initiative built from first principles.</i>
</p>

---

## 📌 What is USUF AI?
**USUF AI** is an open, sovereign research project dedicated to building and pretraining modern autoregressive Large Language Models (**USUF-1**) completely from scratch. 

Unlike conventional applications that merely prompt third-party APIs (such as Gemini, OpenAI GPT, Claude, or Llama), USUF AI engineers:
- **Zero External Pretrained Weights:** All weights are initialized from random Gaussian distributions ($\mathcal{N}(0, 0.02)$).
- **Custom Multilingual Tokenizer:** Byte-Level BPE trained specifically to balance Arabic, English, Code, and Mathematical symbols.
- **7-Stage Data Pipeline:** Strict legal, deduplicated, and filtered open-license corpus curation.
- **Pure PyTorch Architecture:** Custom Decoder-only Transformer implementing RoPE, RMSNorm, and SwiGLU.
- **Transparent Training:** Step-by-step pretraining, supervised instruction fine-tuning (SFT), evaluation, and tooling layers.

---

## 🏗️ Architecture Specification
USUF-1 follows a modern **Decoder-Only Autoregressive Transformer** design:

```
                    ┌───────────────────────────┐
                    │       Output Logits       │
                    └─────────────▲─────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │      RMSNorm (Final)      │
                    └─────────────▲─────────────┘
                                  │
                  ┌───────────────┴───────────────┐
                  │   Transformer Block × N       │
                  │  ┌─────────────────────────┐  │
                  │  │       SwiGLU MLP        │  │
                  │  └────────────▲────────────┘  │
                  │               ┼ Residual      │
                  │  ┌────────────┴────────────┐  │
                  │  │       RMSNorm 2         │  │
                  │  └────────────▲────────────┘  │
                  │               │               │
                  │  ┌────────────┴────────────┐  │
                  │  │  Causal Self-Attention  │  │
                  │  │           + RoPE        │  │
                  │  └────────────▲────────────┘  │
                  │               ┼ Residual      │
                  │  ┌────────────┴────────────┐  │
                  │  │       RMSNorm 1         │  │
                  │  └────────────▲────────────┘  │
                  └───────────────┬───────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │     Token Embeddings      │
                    │   (Tied with LM Head)     │
                    └─────────────▲─────────────┘
                                  │
                           Input Token IDs
```

- **Attention:** Multi-Head Causal Self-Attention with upper-triangular causal attention mask.
- **Positional Encoding:** Rotary Position Embeddings (RoPE) applied to query and key states.
- **Activation:** Swish Gated Linear Unit (SwiGLU).
- **Normalization:** Root Mean Square Normalization (RMSNorm) with pre-normalization layout.
- **Weight Tying:** Output projection matrix is tied with the input token embedding matrix.

---

## 📊 Model Versions Matrix

| Version | Status | Hidden Dim | Layers | Heads | Context | Est. Parameters | Target Stage |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **USUF-0.01** | *NOT TRAINED YET* | 192 | 4 | 6 | 256 | ~1.8 Million | Pipeline proof-of-concept |
| **USUF-0.1** | *PLANNED* | 384 | 8 | 6 | 512 | ~15 Million | Initial semantic learning |
| **USUF-0.5** | *PLANNED* | 576 | 16 | 8 | 1024 | ~60 Million | Sub-scale fluency |
| **USUF-1 (Base)** | *PLANNED* | 768 | 24 | 12 | 2048 | ~130 Million | Production base model |
| **USUF-1-Instruct**| *PLANNED* | 768 | 24 | 12 | 2048 | ~130 Million | Supervised fine-tuning |
| **USUF-1-Chat** | *PLANNED* | 768 | 24 | 12 | 2048 | ~130 Million | Multi-turn conversational |

> **Scientific Honesty Commitment:** As mandated by project charter, all performance metrics will only display verified actual values once training executes. No fabricated benchmarks or marketing claims.

---

## 🔤 Tokenizer Design
- **Algorithm:** Byte-Level Byte-Pair Encoding (BPE).
- **Vocabulary Size:** 32,000 tokens.
- **Byte Fallback:** 100% byte-level coverage ensuring 0% Out-of-Vocabulary (OOV) for Arabic, emoji, code, or math.
- **Special Tokens:**
  - `<unk>`, `<s>`, `</s>`, `<pad>`, `<mask>`
  - Chat tokens: `<|im_start|>system`, `<|im_start|>user`, `<|im_start|>assistant`, `<|im_end|>`
  - Agent tokens: `<|tool_call|>`, `<|tool_return|>`

---

## 📁 Repository Structure
```
USUF-AI/
├── configs/
│   ├── tokenizer.yaml      # BPE vocab, normalizer, and regex splits
│   ├── model.yaml          # Model architecture hyperparameters
│   ├── training.yaml       # Colab adaptive batch, AdamW, cosine schedule
│   └── evaluation.yaml     # Benchmark suites (Arabic, English, Code, Math)
├── data/
│   ├── raw/                # Unprocessed open datasets
│   ├── cleaned/            # UTF-8 normalized text
│   ├── filtered/           # Length, noise, and quality filtering
│   ├── deduplicated/       # MinHash deduplication
│   ├── train/              # Training split (95%)
│   ├── validation/         # Validation split (4%)
│   └── test/               # Benchmark split (1%)
├── tokenizer/
│   ├── train_tokenizer.py  # Phase 1 BPE training script
│   └── tokenizer_utils.py  # Encode, decode, token statistics
├── model/
│   ├── config.py           # Configuration parser & parameter estimator
│   └── ... (Phase 3)
├── training/
│   ├── device.py           # Colab hardware detector & adaptive batcher
│   ├── checkpoint.py       # Atomic checkpoint manager
│   └── ... (Phase 4)
├── notebooks/
│   ├── USUF_Tokenizer.ipynb    # Colab Tokenizer notebook
│   └── USUF_Pretraining.ipynb  # 15-cell Colab Pretraining notebook
├── docs/
│   ├── architecture.md     # Mathematical architecture guide
│   ├── training.md         # Pretraining mechanics & formulas
│   └── roadmap.md          # 12-phase project lifecycle
├── tests/
│   └── test_foundation.py  # Phase 0 verification tests
├── requirements.txt        # Python dependencies
├── pyproject.toml          # Packaging standard
└── LICENSE                 # Apache-2.0 License
```

---

## 🚀 Mobile & Colab Workflow
Engineer Yousuf Albaz conducts development entirely from a mobile phone using:
1. **Google AI Studio:** Code authoring, architectural refinement, mobile dashboard, and GitHub integration.
2. **GitHub:** Version control, release tagging, and configuration management.
3. **Google Colab:** GPU/TPU compute execution, tokenizer training, pretraining loops, and checkpoint storage.

```bash
# 1. Clone repository in Colab
!git clone https://github.com/u-albaz-official/USUF-AI.git
%cd USUF-AI

# 2. Install dependencies
!pip install -r requirements.txt

# 3. Verify foundation tests
!pytest tests/test_foundation.py
```

---

## 🗺️ Project Roadmap
- [x] **PHASE 0: Project Foundation** (Active)
- [ ] **PHASE 1: Tokenizer Training**
- [ ] **PHASE 2: Data Pipeline & Cleaning**
- [ ] **PHASE 3: Decoder-Only Transformer Implementation**
- [ ] **PHASE 4: USUF-0.01 Pretraining**
- [ ] **PHASE 5: Multilingual Evaluation Suite**
- [ ] **PHASE 6: USUF-0.1 Scaling**
- [ ] **PHASE 7: Instruction Tuning (SFT)**
- [ ] **PHASE 8: USUF-1-Chat Model**
- [ ] **PHASE 9: Autoregressive Inference Engine**
- [ ] **PHASE 10: Web & Mobile Interface**
- [ ] **PHASE 11: Tool-Calling Agent System**
- [ ] **PHASE 12: Scaling to USUF-1 Flagship**

---

## ⚠️ Limitations & Governance
- USUF-1 in its early phases (USUF-0.01) is a small proof-of-concept intended to validate gradient propagation, loss convergence, and tokenizer performance. It does not represent a finished chat assistant until Phase 8.
- No proprietary API keys, credentials, or multi-gigabyte data dumps are committed to this repository.

## 📄 License
Licensed under the [Apache License, Version 2.0](LICENSE).
Copyright © 2026 Engineer Yousuf Albaz.
