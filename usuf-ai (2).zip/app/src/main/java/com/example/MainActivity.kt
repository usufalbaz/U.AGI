package com.example

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import coil.compose.AsyncImage
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    TtsManager.init(this)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme(darkTheme = true) {
        UsufAiApp()
      }
    }
  }

  override fun onDestroy() {
    super.onDestroy()
    TtsManager.stop()
  }
}

// Preserve Greeting for tests compatibility
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsufAiApp() {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

  var showSettingsDialog by remember { mutableStateOf(false) }
  var showModelSelectorDialog by remember { mutableStateOf(false) }
  var selectedView by remember { mutableIntStateOf(0) } // 0: ChatGPT Chat, 1: Neural Lab
  var enableWebGrounding by remember { mutableStateOf(false) }

  // Load sessions from repository
  val sessions = remember { mutableStateListOf<ChatSession>() }
  var activeSessionId by remember { mutableStateOf<String?>(null) }

  fun reloadSessions() {
    val loaded = ChatRepository.getAllSessions(context)
    sessions.clear()
    sessions.addAll(loaded)
    val savedActive = ChatRepository.getActiveSessionId(context)
    if (savedActive != null && sessions.any { it.id == savedActive }) {
      activeSessionId = savedActive
    } else if (sessions.isNotEmpty()) {
      activeSessionId = sessions.first().id
      ChatRepository.setActiveSessionId(context, sessions.first().id)
    } else {
      val newS = ChatRepository.createNewSession()
      ChatRepository.saveSession(context, newS)
      sessions.add(newS)
      activeSessionId = newS.id
      ChatRepository.setActiveSessionId(context, newS.id)
    }
  }

  LaunchedEffect(Unit) {
    reloadSessions()
  }

  val activeSession = sessions.find { it.id == activeSessionId } ?: sessions.firstOrNull() ?: ChatSession(
    id = "temp",
    title = "محادثة جديدة",
    updatedAt = System.currentTimeMillis(),
    messages = emptyList()
  )

  if (showSettingsDialog) {
    AiSettingsDialog(onDismiss = { showSettingsDialog = false })
  }

  if (showModelSelectorDialog) {
    ModelSelectorDialog(
      currentModel = GeminiApiService.getSelectedModel(context),
      onModelSelected = { model ->
        GeminiApiService.setSelectedModel(context, model)
        showModelSelectorDialog = false
        Toast.makeText(context, "تم تحديد نموذج $model", Toast.LENGTH_SHORT).show()
      },
      onDismiss = { showModelSelectorDialog = false }
    )
  }

  ModalNavigationDrawer(
    drawerState = drawerState,
    drawerContent = {
      ModalDrawerSheet(
        modifier = Modifier.width(310.dp),
        drawerContainerColor = Color(0xFF0B101B),
        drawerContentColor = Color.White
      ) {
        GptDrawerContent(
          sessions = sessions,
          activeSessionId = activeSessionId,
          selectedView = selectedView,
          onSelectSession = { session ->
            activeSessionId = session.id
            selectedView = 0
            ChatRepository.setActiveSessionId(context, session.id)
            coroutineScope.launch { drawerState.close() }
          },
          onNewChat = {
            val newSession = ChatRepository.createNewSession()
            ChatRepository.saveSession(context, newSession)
            sessions.add(0, newSession)
            activeSessionId = newSession.id
            selectedView = 0
            ChatRepository.setActiveSessionId(context, newSession.id)
            coroutineScope.launch { drawerState.close() }
          },
          onDeleteSession = { sessionId ->
            val updated = ChatRepository.deleteSession(context, sessionId)
            sessions.clear()
            sessions.addAll(updated)
            if (activeSessionId == sessionId) {
              if (sessions.isNotEmpty()) {
                activeSessionId = sessions.first().id
                ChatRepository.setActiveSessionId(context, sessions.first().id)
              } else {
                val newS = ChatRepository.createNewSession()
                ChatRepository.saveSession(context, newS)
                sessions.add(newS)
                activeSessionId = newS.id
                ChatRepository.setActiveSessionId(context, newS.id)
              }
            }
          },
          onOpenNeuralLab = {
            selectedView = 1
            coroutineScope.launch { drawerState.close() }
          },
          onOpenSettings = {
            showSettingsDialog = true
            coroutineScope.launch { drawerState.close() }
          }
        )
      }
    }
  ) {
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      containerColor = SleekBg,
      topBar = {
        GptTopAppBar(
          activeModel = GeminiApiService.getSelectedModel(context),
          enableWebGrounding = enableWebGrounding,
          selectedView = selectedView,
          onToggleWebGrounding = {
            enableWebGrounding = !enableWebGrounding
            val msg = if (enableWebGrounding) "تم تفعيل البحث في الويب (Google Grounding) 🌐" else "تم إيقاف البحث في الويب"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
          },
          onOpenDrawer = { coroutineScope.launch { drawerState.open() } },
          onModelClick = { showModelSelectorDialog = true },
          onNewChat = {
            val newSession = ChatRepository.createNewSession()
            ChatRepository.saveSession(context, newSession)
            sessions.add(0, newSession)
            activeSessionId = newSession.id
            selectedView = 0
            ChatRepository.setActiveSessionId(context, newSession.id)
          },
          onShareChat = {
            shareSession(context, activeSession)
          },
          onOpenSettings = { showSettingsDialog = true }
        )
      }
    ) { paddingValues ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(paddingValues)
      ) {
        when (selectedView) {
          0 -> GptChatMainScreen(
            session = activeSession,
            enableWebGrounding = enableWebGrounding,
            onSessionUpdated = { updatedSession ->
              ChatRepository.saveSession(context, updatedSession)
              val idx = sessions.indexOfFirst { it.id == updatedSession.id }
              if (idx >= 0) {
                sessions[idx] = updatedSession
              } else {
                sessions.add(0, updatedSession)
              }
            }
          )
          1 -> ArchitectureLabContainer(onBackToChat = { selectedView = 0 })
        }
      }
    }
  }
}

fun shareSession(context: Context, session: ChatSession) {
  if (session.messages.isEmpty()) {
    Toast.makeText(context, "لا توجد رسائل لمشاركتها في هذه المحادثة", Toast.LENGTH_SHORT).show()
    return
  }
  val textToShare = buildString {
    appendLine("محادثة من USUF AI: ${session.title}")
    appendLine("==========================================")
    for (m in session.messages) {
      val senderName = if (m.sender == "user") "أنا (المستخدم):" else "USUF AI:"
      appendLine("$senderName\n${m.text}\n")
    }
    appendLine("— تم التوليد عبر USUF AI للمهندس يوسف الباز")
  }
  val intent = Intent(Intent.ACTION_SEND).apply {
    type = "text/plain"
    putExtra(Intent.EXTRA_SUBJECT, session.title)
    putExtra(Intent.EXTRA_TEXT, textToShare)
  }
  context.startActivity(Intent.createChooser(intent, "مشاركة المحادثة عبر"))
}

// -----------------------------------------------------------------------------
// TOP APP BAR (ChatGPT STYLE)
// -----------------------------------------------------------------------------
@Composable
fun GptTopAppBar(
  activeModel: String,
  enableWebGrounding: Boolean,
  selectedView: Int,
  onToggleWebGrounding: () -> Unit,
  onOpenDrawer: () -> Unit,
  onModelClick: () -> Unit,
  onNewChat: () -> Unit,
  onShareChat: () -> Unit,
  onOpenSettings: () -> Unit
) {
  val modelDisplayName = when {
    activeModel.contains("3.5") -> "USUF GPT-4o (3.5 Flash)"
    activeModel.contains("lite") -> "USUF GPT Mini (Flash Lite)"
    else -> "USUF AI ($activeModel)"
  }

  Surface(
    color = SleekHeaderBg,
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Drawer toggle
        IconButton(
          onClick = onOpenDrawer,
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF1E293B))
        ) {
          Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Color.White, modifier = Modifier.size(20.dp))
        }

        // Model Selector Pill (Center)
        Surface(
          onClick = onModelClick,
          shape = RoundedCornerShape(20.dp),
          color = Color(0xFF1E293B),
          border = BorderStroke(1.dp, Color(0xFF334155))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(SleekEmerald)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (selectedView == 0) modelDisplayName else "مختبر المعمارية العصبية",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = SleekTextSlate400, modifier = Modifier.size(16.dp))
          }
        }

        // Actions (Web Search + Share + New Chat + Settings)
        Row(verticalAlignment = Alignment.CenterVertically) {
          // Web Search Grounding Toggle
          IconButton(
            onClick = onToggleWebGrounding,
            modifier = Modifier
              .size(34.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(if (enableWebGrounding) Color(0x3310B981) else Color(0x801E293B))
              .border(
                BorderStroke(1.dp, if (enableWebGrounding) SleekEmerald else Color.Transparent),
                RoundedCornerShape(10.dp)
              )
          ) {
            Icon(
              Icons.Default.Language,
              contentDescription = "Search Web",
              tint = if (enableWebGrounding) SleekEmerald else SleekTextSlate400,
              modifier = Modifier.size(17.dp)
            )
          }

          Spacer(modifier = Modifier.width(4.dp))

          // Share Button
          IconButton(
            onClick = onShareChat,
            modifier = Modifier
              .size(34.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(Color(0xFF1E293B))
          ) {
            Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White, modifier = Modifier.size(16.dp))
          }

          Spacer(modifier = Modifier.width(4.dp))

          // New Chat Button
          IconButton(
            onClick = onNewChat,
            modifier = Modifier
              .size(34.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(Color(0xFF1E293B))
          ) {
            Icon(Icons.Default.AddComment, contentDescription = "New Chat", tint = Color.White, modifier = Modifier.size(16.dp))
          }

          Spacer(modifier = Modifier.width(4.dp))

          // Settings
          IconButton(
            onClick = onOpenSettings,
            modifier = Modifier
              .size(34.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(Color(0xFF1E293B))
          ) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = SleekEmeraldLight, modifier = Modifier.size(16.dp))
          }
        }
      }
      HorizontalDivider(color = SleekNavBorder, thickness = 1.dp)
    }
  }
}

// -----------------------------------------------------------------------------
// CHATGPT DRAWER SIDEBAR
// -----------------------------------------------------------------------------
@Composable
fun GptDrawerContent(
  sessions: List<ChatSession>,
  activeSessionId: String?,
  selectedView: Int,
  onSelectSession: (ChatSession) -> Unit,
  onNewChat: () -> Unit,
  onDeleteSession: (String) -> Unit,
  onOpenNeuralLab: () -> Unit,
  onOpenSettings: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }

  val filteredSessions = remember(sessions, searchQuery) {
    if (searchQuery.isBlank()) sessions else {
      sessions.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .statusBarsPadding()
      .navigationBarsPadding()
      .padding(14.dp)
  ) {
    // Brand header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(listOf(SleekEmerald, SleekIndigo))),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.Black, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text("USUF AI", fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color.White)
          Text("ChatGPT Enterprise AGI", fontSize = 10.sp, color = SleekEmeraldLight)
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // + New Chat button (Primary Action)
    Button(
      onClick = onNewChat,
      modifier = Modifier.fillMaxWidth(),
      colors = ButtonDefaults.buttonColors(containerColor = SleekEmerald),
      shape = RoundedCornerShape(12.dp)
    ) {
      Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black)
      Spacer(modifier = Modifier.width(8.dp))
      Text("محادثة جديدة (+ New Chat)", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Search chats
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text("بحث في المحادثات...", fontSize = 11.sp, color = SleekTextSlate500) },
      modifier = Modifier.fillMaxWidth(),
      singleLine = true,
      shape = RoundedCornerShape(10.dp),
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SleekTextSlate500, modifier = Modifier.size(16.dp)) },
      colors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White,
        focusedBorderColor = SleekEmerald,
        unfocusedBorderColor = Color(0xFF1F2937),
        focusedContainerColor = Color(0xFF030712),
        unfocusedContainerColor = Color(0xFF030712)
      )
    )

    Spacer(modifier = Modifier.height(14.dp))

    Text("سجل المحادثات", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SleekTextSlate400)
    Spacer(modifier = Modifier.height(6.dp))

    // Sessions List
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      items(filteredSessions, key = { it.id }) { session ->
        val isActive = session.id == activeSessionId && selectedView == 0
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isActive) Color(0xFF1E293B) else Color.Transparent)
            .clickable { onSelectSession(session) }
            .padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              Icons.Default.ChatBubbleOutline,
              contentDescription = null,
              tint = if (isActive) SleekEmerald else SleekTextSlate400,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = session.title,
              fontSize = 12.sp,
              color = if (isActive) Color.White else SleekTextSlate300,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }

          IconButton(
            onClick = { onDeleteSession(session.id) },
            modifier = Modifier.size(26.dp)
          ) {
            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = SleekTextSlate500, modifier = Modifier.size(14.dp))
          }
        }
      }
    }

    HorizontalDivider(color = Color(0xFF1F2937), thickness = 1.dp)
    Spacer(modifier = Modifier.height(10.dp))

    // Special item: Architecture Lab
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .background(if (selectedView == 1) Color(0xFF1E293B) else Color.Transparent)
        .clickable { onOpenNeuralLab() }
        .padding(horizontal = 10.dp, vertical = 9.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(Icons.Default.Layers, contentDescription = null, tint = SleekIndigo, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text("معمل المعمارية والتدريب", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Transformer Lab & Colab Pipeline", fontSize = 9.sp, color = SleekTextSlate500)
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // User Profile Card (Eng. Yousuf Albaz)
    Card(
      colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, Color(0xFF1F2937)),
      modifier = Modifier
        .fillMaxWidth()
        .clickable { onOpenSettings() }
    ) {
      Row(
        modifier = Modifier.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(SleekEmerald),
          contentAlignment = Alignment.Center
        ) {
          Text("YA", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text("م. يوسف الباز", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
          Text("Automation AI • Pro AGI", fontSize = 9.sp, color = SleekEmeraldLight)
        }
        Icon(Icons.Default.Settings, contentDescription = null, tint = SleekTextSlate400, modifier = Modifier.size(16.dp))
      }
    }
  }
}

// -----------------------------------------------------------------------------
// MAIN CHAT SCREEN (Full ChatGPT Experience)
// -----------------------------------------------------------------------------
@Composable
fun GptChatMainScreen(
  session: ChatSession,
  enableWebGrounding: Boolean,
  onSessionUpdated: (ChatSession) -> Unit
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val listState = rememberLazyListState()

  var inputText by remember { mutableStateOf("") }
  var isGenerating by remember { mutableStateOf(false) }
  var streamingOutput by remember { mutableStateOf("") }
  var selectedImageUri by remember { mutableStateOf<Uri?>(null) }

  // Photo Picker Launcher (Android Photo Picker - Zero Permission & Play Store compliant)
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri ->
    if (uri != null) {
      selectedImageUri = uri
    }
  }

  // Voice Input Launcher (SpeechRecognizer)
  val speechRecognizerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK && result.data != null) {
      val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
      if (!spoken.isNullOrBlank()) {
        inputText = if (inputText.isBlank()) spoken else "$inputText $spoken"
      }
    }
  }

  fun sendMessage(promptText: String, attachedUri: Uri? = selectedImageUri) {
    val cleanPrompt = promptText.trim()
    if ((cleanPrompt.isBlank() && attachedUri == null) || isGenerating) return

    inputText = ""
    val currentUri = attachedUri
    selectedImageUri = null

    val userMsg = ChatMessage(
      id = System.currentTimeMillis().toString(),
      sender = "user",
      text = cleanPrompt.ifBlank { "تحليل الصورة المرفقة 📷" },
      timestamp = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
      tokensCount = (cleanPrompt.length / 3).coerceAtLeast(1),
      imageUri = currentUri?.toString()
    )

    val updatedMessages = session.messages + userMsg
    val autoTitle = if (session.messages.isEmpty() || session.title == "محادثة جديدة") {
      val t = if (cleanPrompt.isNotBlank()) cleanPrompt else "تحليل صورة"
      t.take(30) + if (t.length > 30) "..." else ""
    } else {
      session.title
    }

    val updatedSession = session.copy(
      title = autoTitle,
      updatedAt = System.currentTimeMillis(),
      messages = updatedMessages
    )
    onSessionUpdated(updatedSession)

    // Call Gemini AGI with streaming feedback and image data
    isGenerating = true
    streamingOutput = ""

    coroutineScope.launch {
      // Scroll to bottom
      delay(50)
      listState.animateScrollToItem(updatedMessages.size - 1)

      val imageBase64Pair = if (currentUri != null) {
        GeminiApiService.uriToBase64(context, currentUri)
      } else null

      val result = GeminiApiService.askGemini(
        context = context,
        history = updatedMessages,
        newPrompt = cleanPrompt,
        enableWebGrounding = enableWebGrounding,
        imageBase64 = imageBase64Pair?.first,
        imageMimeType = imageBase64Pair?.second
      )

      result.onSuccess { fullReply ->
        // Simulate real-time word streaming for ChatGPT fluidity
        val words = fullReply.split(" ")
        val sb = StringBuilder()
        for (w in words) {
          sb.append(w).append(" ")
          streamingOutput = sb.toString()
          delay(20)
        }

        val assistantMsg = ChatMessage(
          id = (System.currentTimeMillis() + 1).toString(),
          sender = "assistant",
          text = fullReply,
          timestamp = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
          tokensCount = (fullReply.length / 3).coerceAtLeast(1)
        )
        val finalMessages = updatedMessages + assistantMsg
        onSessionUpdated(
          updatedSession.copy(
            updatedAt = System.currentTimeMillis(),
            messages = finalMessages
          )
        )
        streamingOutput = ""
        isGenerating = false
        delay(60)
        listState.animateScrollToItem(finalMessages.size - 1)
      }.onFailure { error ->
        val errorMsg = ChatMessage(
          id = (System.currentTimeMillis() + 1).toString(),
          sender = "assistant",
          text = "⚠️ عذراً، واجهنا خطأ في الاستجابة:\n${error.message}\n\nيرجى التأكد من اتصال الإنترنت أو فحص مفتاح API من زر الإعدادات ⚙️.",
          timestamp = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
          tokensCount = 10
        )
        val finalMessages = updatedMessages + errorMsg
        onSessionUpdated(
          updatedSession.copy(
            updatedAt = System.currentTimeMillis(),
            messages = finalMessages
          )
        )
        streamingOutput = ""
        isGenerating = false
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .navigationBarsPadding()
      .padding(horizontal = 14.dp, vertical = 6.dp)
  ) {
    // Chat Area
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
    ) {
      if (session.messages.isEmpty()) {
        // ChatGPT Hero Empty State
        GptEmptyHeroState(onSelectPrompt = { prompt -> sendMessage(prompt) })
      } else {
        LazyColumn(
          state = listState,
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(16.dp),
          contentPadding = PaddingValues(vertical = 12.dp)
        ) {
          items(session.messages, key = { it.id }) { msg ->
            GptMessageRow(
              msg = msg,
              onCopyText = { text ->
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("USUF AI Message", text))
                Toast.makeText(context, "تم نسخ النص!", Toast.LENGTH_SHORT).show()
              },
              onSpeak = { text ->
                TtsManager.toggleSpeak(text, context)
              },
              onRegenerate = {
                // Find last user prompt
                val lastUserMsg = session.messages.findLast { it.sender == "user" }
                if (lastUserMsg != null) {
                  sendMessage(lastUserMsg.text)
                }
              }
            )
          }

          // Real-time Streaming message
          if (isGenerating && streamingOutput.isNotBlank()) {
            item {
              val streamMsg = ChatMessage(
                id = "streaming",
                sender = "assistant",
                text = "$streamingOutput ▊",
                timestamp = "الآن"
              )
              GptMessageRow(
                msg = streamMsg,
                isStreaming = true,
                onCopyText = {},
                onSpeak = {},
                onRegenerate = {}
              )
            }
          } else if (isGenerating) {
            item {
              Row(
                modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .background(Color(0xFF0F172A))
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = SleekEmerald, strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Text("USUF AI يفكر ويستنتج الإجابة...", fontSize = 12.sp, color = SleekEmeraldLight)
              }
            }
          }
        }
      }
    }

    // Attached image preview chip
    if (selectedImageUri != null) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFF1E293B),
          border = BorderStroke(1.dp, SleekEmerald)
        ) {
          Row(
            modifier = Modifier.padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            AsyncImage(
              model = selectedImageUri,
              contentDescription = "Selected image preview",
              modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(8.dp))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("صورة مرفقة للتحليل 📷", fontSize = 11.sp, color = SleekEmeraldLight)
            Spacer(modifier = Modifier.width(6.dp))
            IconButton(
              onClick = { selectedImageUri = null },
              modifier = Modifier.size(24.dp)
            ) {
              Icon(Icons.Default.Close, contentDescription = "Remove", tint = SleekTextSlate400, modifier = Modifier.size(16.dp))
            }
          }
        }
      }
    }

    // Input Bar (ChatGPT Style Pill)
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = Color(0xFF1E293B),
      border = BorderStroke(1.dp, if (enableWebGrounding) SleekEmerald else Color(0xFF334155)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Photo Picker button
        IconButton(
          onClick = {
            photoPickerLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
          },
          modifier = Modifier.size(36.dp)
        ) {
          Icon(
            Icons.Default.AddPhotoAlternate,
            contentDescription = "Attach image",
            tint = if (selectedImageUri != null) SleekEmerald else SleekTextSlate400,
            modifier = Modifier.size(20.dp)
          )
        }

        // Voice Input (Mic) button
        IconButton(
          onClick = {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
              putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
              putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
              putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث الآن إلى USUF AI...")
            }
            try {
              speechRecognizerLauncher.launch(intent)
            } catch (e: Exception) {
              Toast.makeText(context, "التعرف الصوتي غير متوفر على هذا الجهاز", Toast.LENGTH_SHORT).show()
            }
          },
          modifier = Modifier.size(36.dp)
        ) {
          Icon(
            Icons.Default.Mic,
            contentDescription = "Voice input",
            tint = SleekEmeraldLight,
            modifier = Modifier.size(20.dp)
          )
        }

        // Grounding web indicator
        if (enableWebGrounding) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0x3310B981))
              .padding(horizontal = 6.dp, vertical = 3.dp)
          ) {
            Text("ويب 🌐", fontSize = 10.sp, color = SleekEmerald, fontWeight = FontWeight.Bold)
          }
          Spacer(modifier = Modifier.width(4.dp))
        }

        OutlinedTextField(
          value = inputText,
          onValueChange = { inputText = it },
          modifier = Modifier.weight(1f),
          placeholder = {
            Text(
              if (selectedImageUri != null) "اسأل عن الصورة المرفقة..."
              else if (enableWebGrounding) "اسأل مع البحث في الويب..."
              else "اسأل USUF AI أي سؤال...",
              fontSize = 12.sp,
              color = SleekTextSlate500
            )
          },
          colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedContainerColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent
          ),
          maxLines = 4
        )

        IconButton(
          onClick = { sendMessage(inputText) },
          enabled = (inputText.isNotBlank() || selectedImageUri != null) && !isGenerating,
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(
              if ((inputText.isNotBlank() || selectedImageUri != null) && !isGenerating) SleekEmerald
              else Color(0xFF334155)
            )
        ) {
          Icon(
            Icons.AutoMirrored.Filled.Send,
            contentDescription = "Send",
            tint = if ((inputText.isNotBlank() || selectedImageUri != null) && !isGenerating) Color.Black
            else SleekTextSlate500,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = "USUF AI مدعوم بمحركات الذكاء الاصطناعي العام. يرجى مراجعة الإجابات الحساسة.",
      fontSize = 9.sp,
      color = SleekTextSlate500,
      textAlign = TextAlign.Center,
      modifier = Modifier.fillMaxWidth()
    )
  }
}

// -----------------------------------------------------------------------------
// CHATGPT HERO EMPTY STATE
// -----------------------------------------------------------------------------
@Composable
fun GptEmptyHeroState(onSelectPrompt: (String) -> Unit) {
  val suggestions = listOf(
    "اكتب كود كامل لتدريب Transformer على PyTorch مع معمارية Decoder-Only",
    "اشرح بالتفصيل كيف يعمل Attention و RoPE رياضياً في النماذج اللغوية",
    "حل مسألة تحسين Gradient Descent واشرح معادلة AdamW خطوة بخطوة",
    "اكتب خطة إطلاق تطبيق ذكاء اصطناعي تجاري ناجح للمهندس يوسف الباز"
  )

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(60.dp)
        .clip(CircleShape)
        .background(Brush.radialGradient(listOf(SleekEmerald, Color(0xFF0F172A)))),
      contentAlignment = Alignment.Center
    ) {
      Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.Black, modifier = Modifier.size(32.dp))
    }

    Spacer(modifier = Modifier.height(14.dp))

    Text(
      text = "بماذا يمكنني مساعدتك اليوم يا مهندس يوسف؟",
      fontSize = 17.sp,
      fontWeight = FontWeight.Bold,
      color = Color.White,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = "نموذج ذكاء اصطناعي عام (AGI) فائق التطور للإجابة عن أي شيء بدقة متناهية.",
      fontSize = 11.sp,
      color = SleekTextSlate400,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(24.dp))

    // 4 Suggestion Cards
    Column(
      modifier = Modifier.fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      for (prompt in suggestions) {
        Surface(
          onClick = { onSelectPrompt(prompt) },
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFF1E293B),
          border = BorderStroke(1.dp, Color(0xFF334155)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = SleekEmerald, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = prompt, fontSize = 11.sp, color = SleekTextSlate300, maxLines = 2, overflow = TextOverflow.Ellipsis)
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// CHATGPT MESSAGE ROW
// -----------------------------------------------------------------------------
@Composable
fun GptMessageRow(
  msg: ChatMessage,
  isStreaming: Boolean = false,
  onCopyText: (String) -> Unit,
  onSpeak: (String) -> Unit,
  onRegenerate: () -> Unit
) {
  val isUser = msg.sender == "user"
  val context = LocalContext.current

  Column(
    modifier = Modifier.fillMaxWidth(),
    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
  ) {
    if (!isUser) {
      // Assistant Header
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 6.dp)
      ) {
        Box(
          modifier = Modifier
            .size(20.dp)
            .clip(CircleShape)
            .background(SleekEmerald),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text("USUF AI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SleekEmeraldLight)
        Spacer(modifier = Modifier.width(6.dp))
        Text(msg.timestamp, fontSize = 9.sp, color = SleekTextSlate500)
      }
    }

    Surface(
      shape = RoundedCornerShape(
        topStart = 16.dp,
        topEnd = 16.dp,
        bottomStart = if (isUser) 16.dp else 4.dp,
        bottomEnd = if (isUser) 4.dp else 16.dp
      ),
      color = if (isUser) Color(0xFF1E3A8A) else Color(0xFF111827),
      border = BorderStroke(1.dp, if (isUser) Color(0xFF2563EB) else Color(0xFF1F2937)),
      modifier = Modifier.widthIn(max = 330.dp)
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        if (!msg.imageUri.isNullOrBlank()) {
          AsyncImage(
            model = msg.imageUri,
            contentDescription = "User uploaded image",
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 220.dp)
              .clip(RoundedCornerShape(10.dp))
              .padding(bottom = 8.dp)
          )
        }
        FormattedMessageContent(
          text = msg.text,
          isUser = isUser,
          onCopyCode = { code ->
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Code", code))
            Toast.makeText(context, "تم نسخ الكود البرمجي!", Toast.LENGTH_SHORT).show()
          }
        )
      }
    }

    if (!isUser && !isStreaming) {
      // Action Row under assistant messages (Copy, TTS Speak, Regenerate, Share)
      Row(
        modifier = Modifier.padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = { onCopyText(msg.text) }, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = SleekTextSlate400, modifier = Modifier.size(14.dp))
        }
        IconButton(onClick = { onSpeak(msg.text) }, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.VolumeUp, contentDescription = "Speak", tint = SleekTextSlate400, modifier = Modifier.size(15.dp))
        }
        IconButton(onClick = {
          val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, msg.text)
          }
          context.startActivity(Intent.createChooser(sendIntent, "مشاركة إجابة USUF AI عبر"))
        }, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.Share, contentDescription = "Share", tint = SleekTextSlate400, modifier = Modifier.size(14.dp))
        }
        IconButton(onClick = onRegenerate, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.Refresh, contentDescription = "Regenerate", tint = SleekTextSlate400, modifier = Modifier.size(14.dp))
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// MODEL SELECTOR DIALOG
// -----------------------------------------------------------------------------
@Composable
fun ModelSelectorDialog(
  currentModel: String,
  onModelSelected: (String) -> Unit,
  onDismiss: () -> Unit
) {
  val models = listOf(
    Pair("gemini-3.5-flash", "USUF GPT-4o (Gemini 3.5 Flash) - الذكاء الفائق والاستنتاج المنطقي"),
    Pair("gemini-3.1-flash-lite-preview", "USUF GPT Mini (Flash Lite) - فائق السرعة والخفة"),
    Pair("gemini-flash-latest", "USUF GPT Balanced - التوازن بين السرعة والدقة")
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("اختر نموذج الذكاء الاصطناعي", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White) },
    containerColor = Color(0xFF0F172A),
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for ((modelId, label) in models) {
          val isSelected = currentModel == modelId
          Surface(
            onClick = { onModelSelected(modelId) },
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) Color(0xFF1E293B) else Color.Transparent,
            border = BorderStroke(1.dp, if (isSelected) SleekEmerald else Color(0xFF334155)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              RadioButton(
                selected = isSelected,
                onClick = { onModelSelected(modelId) },
                colors = RadioButtonDefaults.colors(selectedColor = SleekEmerald)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = label, fontSize = 11.sp, color = Color.White)
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("إغلاق", color = SleekEmerald)
      }
    }
  )
}

// -----------------------------------------------------------------------------
// NEURAL LAB CONTAINER (Access to Transformer Architecture from Drawer)
// -----------------------------------------------------------------------------
@Composable
fun ArchitectureLabContainer(onBackToChat: () -> Unit) {
  var selectedTab by remember { mutableIntStateOf(0) }

  Column(modifier = Modifier.fillMaxSize()) {
    Surface(color = Color(0xFF0F172A), modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onBackToChat) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
          Text("مختبر الهندسة العصبية", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
        }

        ScrollableTabRow(
          selectedTabIndex = selectedTab,
          containerColor = Color.Transparent,
          contentColor = SleekEmerald,
          edgePadding = 0.dp
        ) {
          Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("التوليد", fontSize = 10.sp) })
          Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("التقطيع BPE", fontSize = 10.sp) })
          Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("المعمارية", fontSize = 10.sp) })
          Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Colab", fontSize = 10.sp) })
        }
      }
    }

    Box(modifier = Modifier.weight(1f)) {
      when (selectedTab) {
        0 -> AutoregressiveGenerationTab()
        1 -> TokenizerPlaygroundTab()
        2 -> ArchitectureAndCalculatorTab()
        3 -> CompletePipelineTab()
      }
    }
  }
}
