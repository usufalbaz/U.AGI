package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun generateSmartReply(prompt: String): String {
  val p = prompt.lowercase()
  return when {
    p.contains("transformer") || p.contains("ترانسفورمر") -> {
      "معمارية الـ Transformer المعتمدة في USUF-1 هي معمارية Decoder-Only تعتمد على Causal Self-Attention:\n\n" +
          "1. **Input Tokens**: يتم تحويل الكلمات إلى أرقام عبر BPE Tokenizer (32k).\n" +
          "2. **Rotary Positional Embeddings (RoPE)**: ترميز المواضع رياضياً لتدوير مصفوفات Q و K.\n" +
          "3. **RMSNorm**: تطبيع المتجهات قبل الانتباه لضمان استقرار المشتقات الرياضية.\n" +
          "4. **SwiGLU FFN**: دالة تنشيط غير خطية تمنح النموذج قدرة تمثيل أعلى من ReLU و GELU."
    }
    p.contains("colab") || p.contains("كولاب") || p.contains("تدريب") -> {
      "لتشغيل التدريب على Google Colab بخطوات بسيطة:\n\n" +
          "1. افتح تبويب **PIPELINE** في الأسفل وانسخ أمر git clone.\n" +
          "2. افتح دفتر `USUF_Pretraining.ipynb` في Colab.\n" +
          "3. شغل الخلايا بالترتيب؛ يقوم سكربت `device.py` تلقائياً باكتشاف ذاكرة GPU وضبط حجم الدفعة (Batch Size) لمنع أخطاء OOM.\n" +
          "4. تحفظ الأوزان ذرياً في مجلد `checkpoints/` بحيث يمكنك استئناف التدريب بأي وقت."
    }
    p.contains("rope") || p.contains("position") -> {
      "تقنية RoPE (Rotary Position Embedding) تدور متجهات Q و K بزاوية تتناسب مع موضع الكلمة في الجملة.\n\n" +
          "الميزة الجوهرية لـ RoPE:\n" +
          "• عدد المعايير القابلة للتدريب = 0 (تحسب رياضياً).\n" +
          "• تتيح تعميم أطوال سياق أطول (Context Length Extrapolation) أفضل من التضمين التقليدي الثابت."
    }
    p.contains("attention") || p.contains("انتباه") || p.contains("pytorch") -> {
      "معادلة الـ Scaled Dot-Product Attention الأساسية:\n\n" +
          "Attention(Q, K, V) = softmax((Q * K^T) / sqrt(d_k) + M) * V\n\n" +
          "حيث M هو القناع السببي (Causal Mask) الذي يمنع الرمز من النظر إلى الرموز المستقبلية، مما يضمن التوليد التتابعي الصحيح."
    }
    else -> {
      "أهلاً بك يا مهندس يوسف في USUF AI Studio! " +
          "يمكنك سؤالي عن أي موضوع علمي أو برمجي، أو استخدام معمل المعمارية لفحص وتدريب نماذج Transformer مخصصة."
    }
  }
}

// -----------------------------------------------------------------------------
// TAB 1: AUTOREGRESSIVE GENERATION TEST
// -----------------------------------------------------------------------------
@Composable
fun AutoregressiveGenerationTab() {
  val coroutineScope = rememberCoroutineScope()
  var promptInput by remember { mutableStateOf("الذكاء الاصطناعي هو") }
  var generatedOutput by remember { mutableStateOf("") }
  var isGenerating by remember { mutableStateOf(false) }

  var temperature by remember { mutableFloatStateOf(0.7f) }
  var topP by remember { mutableFloatStateOf(0.9f) }
  var maxTokens by remember { mutableFloatStateOf(64f) }

  fun runGeneration() {
    if (isGenerating) return
    isGenerating = true
    generatedOutput = ""

    val sampleContinuations = listOf(
      " تقنية تمكن الحواسيب من محاكاة القدرات العقلية البشرية كالتعلم والاستنتاج والتحليل.",
      " منظومة خوارزمية مبنية على شبكات عصبية اصطناعية تعتمد على معمارية Transformer Decoder-Only.",
      " أداة ثورية في تحليل البيانات البرمجية والنصوص، وتدريب نماذج لغة مستقلة تماماً من الصفر."
    )
    val chosenContinuation = sampleContinuations.random()

    coroutineScope.launch {
      val words = chosenContinuation.split(" ")
      for (word in words) {
        generatedOutput += "$word "
        delay(110)
      }
      isGenerating = false
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = SleekCardBg),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SleekWhiteBorder)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("توليد النص التتابعي (Autoregressive Inference)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SleekTextWhite)
          Spacer(modifier = Modifier.height(4.dp))
          Text("محاكاة توقع الرمز التالي (Next-Token Prediction) بدوال أخذ العينات العشوائية.", fontSize = 11.sp, color = SleekTextSlate400)

          Spacer(modifier = Modifier.height(14.dp))

          OutlinedTextField(
            value = promptInput,
            onValueChange = { promptInput = it },
            label = { Text("المُدخل (Prompt)", fontSize = 11.sp) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedBorderColor = SleekEmerald,
              unfocusedBorderColor = Color(0xFF334155),
              focusedContainerColor = Color(0xFF0F172A),
              unfocusedContainerColor = Color(0xFF0F172A)
            )
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("درجة العشوائية (Temperature): ${String.format("%.2f", temperature)}", fontSize = 11.sp, color = SleekTextSlate300)
          }
          Slider(
            value = temperature,
            onValueChange = { temperature = it },
            valueRange = 0.1f..1.5f,
            colors = SliderDefaults.colors(thumbColor = SleekEmerald, activeTrackColor = SleekEmerald)
          )

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("نطاق الاحتمالية (Top-p): ${String.format("%.2f", topP)}", fontSize = 11.sp, color = SleekTextSlate300)
          }
          Slider(
            value = topP,
            onValueChange = { topP = it },
            valueRange = 0.1f..1.0f,
            colors = SliderDefaults.colors(thumbColor = SleekIndigo, activeTrackColor = SleekIndigo)
          )

          Spacer(modifier = Modifier.height(10.dp))

          Button(
            onClick = { runGeneration() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isGenerating && promptInput.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = SleekEmerald),
            shape = RoundedCornerShape(12.dp)
          ) {
            if (isGenerating) {
              CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
              Spacer(modifier = Modifier.width(8.dp))
              Text("جاري التوليد الرمزي...", color = Color.Black, fontWeight = FontWeight.Bold)
            } else {
              Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
              Spacer(modifier = Modifier.width(6.dp))
              Text("بدء التوليد التتابعي", color = Color.Black, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    if (generatedOutput.isNotBlank() || isGenerating) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = Color(0xFF0A101F)),
          shape = RoundedCornerShape(16.dp),
          border = BorderStroke(1.dp, SleekEmerald)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("مُخرجات النموذج المتولدة", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SleekEmeraldLight)
              Text("Tokens: ${generatedOutput.split(" ").size}", fontSize = 10.sp, color = SleekTextSlate400)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = promptInput + generatedOutput,
              fontSize = 13.sp,
              color = Color.White,
              lineHeight = 20.sp
            )
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// TAB 2: TOKENIZER PLAYGROUND
// -----------------------------------------------------------------------------
@Composable
fun TokenizerPlaygroundTab() {
  var sampleText by remember { mutableStateOf("مهندس يوسف الباز يبني نموذج الذكاء الاصطناعي USUF AI من الصفر.") }

  val tokens = remember(sampleText) {
    val regex = "([\\u0600-\\u06FF]+|[a-zA-Z0-9_]+|[^\\s\\w])".toRegex()
    val matches = regex.findAll(sampleText).map { it.value }.toList()
    if (matches.isEmpty()) listOf("فارغ") else matches
  }

  val tokenColors = listOf(
    Color(0xFF3B82F6),
    Color(0xFF10B981),
    Color(0xFF8B5CF6),
    Color(0xFFF59E0B),
    Color(0xFFEC4899),
    Color(0xFF06B6D4)
  )

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = SleekCardBg),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SleekWhiteBorder)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("مختبر التقطيع اللغوي (BPE Tokenizer)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SleekTextWhite)
          Spacer(modifier = Modifier.height(4.dp))
          Text("معاينة بصرية لكيفية تحويل النصوص العربية والإنجليزية إلى Tokens متمايزة بألوان معرفية.", fontSize = 11.sp, color = SleekTextSlate400)

          Spacer(modifier = Modifier.height(14.dp))

          OutlinedTextField(
            value = sampleText,
            onValueChange = { sampleText = it },
            label = { Text("النص المراد تقطيعه", fontSize = 11.sp) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White,
              focusedBorderColor = SleekEmerald,
              unfocusedBorderColor = Color(0xFF334155),
              focusedContainerColor = Color(0xFF0F172A),
              unfocusedContainerColor = Color(0xFF0F172A)
            ),
            maxLines = 4
          )
        }
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = SleekCardBg),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SleekWhiteBorder)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("الرموز المقطعة (${tokens.size} Tokens)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SleekTextWhite)
            Text("Compression: ${String.format("%.1f", sampleText.length.toFloat() / (tokens.size.coerceAtLeast(1)))}x", fontSize = 11.sp, color = SleekEmeraldLight)
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            tokens.take(12).forEachIndexed { index, token ->
              val col = tokenColors[index % tokenColors.size]
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(col.copy(alpha = 0.2f))
                  .border(BorderStroke(1.dp, col), RoundedCornerShape(6.dp))
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(text = token, fontSize = 11.sp, color = Color.White)
              }
            }
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// TAB 3: ARCHITECTURE & MEMORY CALCULATOR
// -----------------------------------------------------------------------------
@Composable
fun ArchitectureAndCalculatorTab() {
  var dModel by remember { mutableFloatStateOf(512f) }
  var numLayers by remember { mutableFloatStateOf(6f) }
  var numHeads by remember { mutableFloatStateOf(8f) }
  var vocabSize by remember { mutableFloatStateOf(32000f) }

  val totalParamsMillions = remember(dModel, numLayers, vocabSize) {
    val embedParams = vocabSize * dModel
    val perLayerParams = (4 * dModel * dModel) + (3 * dModel * (dModel * 4))
    val total = embedParams + (numLayers * perLayerParams)
    total / 1_000_000f
  }

  val vramFp16Gb = remember(totalParamsMillions) {
    (totalParamsMillions * 1_000_000 * 2) / (1024f * 1024f * 1024f)
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = SleekCardBg),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SleekWhiteBorder)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("حاسبة المعمارية وذاكرة VRAM التفاعلية", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SleekTextWhite)
          Spacer(modifier = Modifier.height(4.dp))
          Text("احسب فورياً حجم المعاملات وذاكرة كرت الشاشة المطلوبة للتدريب.", fontSize = 11.sp, color = SleekTextSlate400)

          Spacer(modifier = Modifier.height(14.dp))

          Text("بُعد التضمين (d_model): ${dModel.toInt()}", fontSize = 11.sp, color = SleekTextSlate300)
          Slider(value = dModel, onValueChange = { dModel = it }, valueRange = 256f..2048f, steps = 6)

          Text("عدد الطبقات (Layers): ${numLayers.toInt()}", fontSize = 11.sp, color = SleekTextSlate300)
          Slider(value = numLayers, onValueChange = { numLayers = it }, valueRange = 2f..32f, steps = 14)

          Text("رؤوس الانتباه (Heads): ${numHeads.toInt()}", fontSize = 11.sp, color = SleekTextSlate300)
          Slider(value = numHeads, onValueChange = { numHeads = it }, valueRange = 4f..32f, steps = 6)
        }
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SleekEmerald)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("إجمالي المعاملات", fontSize = 11.sp, color = SleekTextSlate400)
            Spacer(modifier = Modifier.height(4.dp))
            Text("${String.format("%.1f", totalParamsMillions)}M", fontSize = 20.sp, fontWeight = FontWeight.Black, color = SleekEmeraldLight)
            Text("Parameters", fontSize = 9.sp, color = SleekTextSlate500)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ذاكرة VRAM (FP16)", fontSize = 11.sp, color = SleekTextSlate400)
            Spacer(modifier = Modifier.height(4.dp))
            Text("${String.format("%.2f", vramFp16Gb)} GB", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color(0xFF60A5FA))
            Text("Weights Memory", fontSize = 9.sp, color = SleekTextSlate500)
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// TAB 4: COMPLETE TRAINING PIPELINE
// -----------------------------------------------------------------------------
@Composable
fun CompletePipelineTab() {
  val context = LocalContext.current

  fun copyToClipboard(text: String, label: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "تم نسخ $label!", Toast.LENGTH_SHORT).show()
  }

  val fullColabScript = """
# =============================================================================
#              USUF AI - Transformer Training Script for Colab
#              Lead Developer: Engineer Yousuf Albaz
# =============================================================================
import os, math, time, torch
import torch.nn as nn
import torch.nn.functional as F

print("🚀 مرحباً بك يا مهندس يوسف الباز في معمل تدريب USUF AI")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"الجهاز المستخدم: {device}")

# 1. بيانات التدريب المصغرة (علوم الذكاء الاصطناعي والبرمجة)
training_text = '''
مرحباً بكم في مشروع USUF AI الخاص بالمهندس يوسف الباز.
الذكاء الاصطناعي العام AGI يحاكي قدرات العقل البشري في التحليل والفهم.
معمارية Transformer هي الأساس الذي بنيت عليه نماذج اللغة الكبيرة GPT.
تعتمد المعمارية على آليات الانتباه الذاتي Causal Self-Attention.
تقنية Rotary Position Embedding RoPE تستخدم لتشفير المواضع رياضياً.
دالة RMSNorm تضمن استقرار المشتقات وتسريع التقارب العصبي.
دالة التنشيط SwiGLU توفر قدرة تمثيلية فائقة لشبكات MLP.
USUF AI is an advanced generative AI model designed by Engineer Yousuf Albaz.
Artificial General Intelligence represents the future of deep learning.
''' * 40

# 2. Tokenizer مبسّط
chars = sorted(list(set(training_text)))
vocab_size = len(chars)
char_to_id = {ch: i for i, ch in enumerate(chars)}
id_to_char = {i: ch for i, ch in enumerate(chars)}
encode = lambda s: [char_to_id[c] for c in s if c in char_to_id]
decode = lambda l: ''.join([id_to_char[i] for i in l if i in id_to_char])
print(f"📊 حجم المفردات (Vocab Size): {vocab_size} رمز")

data = torch.tensor(encode(training_text), dtype=torch.long)
n = int(0.9 * len(data))
train_data, val_data = data[:n], data[n:]

# 3. معمارية نموذج USUF-0.01
class RMSNorm(nn.Module):
    def __init__(self, dim, eps=1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))
    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps) * self.weight

class CausalSelfAttention(nn.Module):
    def __init__(self, hidden_size, num_heads):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.qkv_proj = nn.Linear(hidden_size, 3 * hidden_size, bias=False)
        self.out_proj = nn.Linear(hidden_size, hidden_size, bias=False)
    def forward(self, x):
        B, T, C = x.size()
        qkv = self.qkv_proj(x).chunk(3, dim=-1)
        q, k, v = [t.view(B, T, self.num_heads, self.head_dim).transpose(1, 2) for t in qkv]
        out = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        return self.out_proj(out.transpose(1, 2).contiguous().view(B, T, C))

class SwiGLUMlp(nn.Module):
    def __init__(self, hidden_size, intermediate_size):
        super().__init__()
        self.w1 = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.w2 = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.w3 = nn.Linear(intermediate_size, hidden_size, bias=False)
    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))

class TransformerBlock(nn.Module):
    def __init__(self, hidden_size, num_heads, intermediate_size):
        super().__init__()
        self.norm1 = RMSNorm(hidden_size)
        self.attn = CausalSelfAttention(hidden_size, num_heads)
        self.norm2 = RMSNorm(hidden_size)
        self.mlp = SwiGLUMlp(hidden_size, intermediate_size)
    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        return x + self.mlp(self.norm2(x))

class USUFTransformer(nn.Module):
    def __init__(self, vocab_size, hidden_size=128, num_layers=4, num_heads=4, intermediate_size=256, max_seq_len=128):
        super().__init__()
        self.max_seq_len = max_seq_len
        self.token_embeddings = nn.Embedding(vocab_size, hidden_size)
        self.pos_embeddings = nn.Embedding(max_seq_len, hidden_size)
        self.blocks = nn.ModuleList([TransformerBlock(hidden_size, num_heads, intermediate_size) for _ in range(num_layers)])
        self.norm_final = RMSNorm(hidden_size)
        self.lm_head = nn.Linear(hidden_size, vocab_size, bias=False)
        self.token_embeddings.weight = self.lm_head.weight
    def forward(self, idx, targets=None):
        B, T = idx.size()
        x = self.token_embeddings(idx) + self.pos_embeddings(torch.arange(T, device=idx.device))
        for block in self.blocks:
            x = block(x)
        logits = self.lm_head(self.norm_final(x))
        loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1)) if targets is not None else None
        return logits, loss
    @torch.no_grad()
    def generate(self, idx, max_new_tokens=80, temperature=0.8):
        for _ in range(max_new_tokens):
            idx_cond = idx[:, -self.max_seq_len:]
            logits, _ = self(idx_cond)
            probs = F.softmax(logits[:, -1, :] / temperature, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, next_token), dim=1)
        return idx

# 4. بناء النموذج وتدريبه
model = USUFTransformer(vocab_size=vocab_size).to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
batch_size, block_size, epochs = 16, 64, 300

def get_batch():
    ix = torch.randint(len(train_data) - block_size, (batch_size,))
    x = torch.stack([train_data[i:i+block_size] for i in ix])
    y = torch.stack([train_data[i+1:i+block_size+1] for i in ix])
    return x.to(device), y.to(device)

print("\n🚀 بدء عملية تدريب النموذج...")
start_time = time.time()
for epoch in range(1, epochs + 1):
    xb, yb = get_batch()
    logits, loss = model(xb, yb)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    if epoch % 50 == 0 or epoch == 1:
        print(f"خطوة [{epoch}/{epochs}] — قيمة الخطأ (Loss): {loss.item():.4f}")

print(f"✅ اكتمل التدريب بنجاح في {time.time() - start_time:.2f} ثانية!")
torch.save(model.state_dict(), "usuf_model_weights.pt")
print("💾 تم حفظ أوزان النموذج في الملف: usuf_model_weights.pt")

# 5. اختبار الاستنتاج
print("\n" + "=" * 50)
print("🎯 نتيجة اختبار التوليد من نموذج USUF:")
context_tokens = torch.tensor([encode("مرحباً بكم في")], dtype=torch.long, device=device)
output = decode(model.generate(context_tokens, max_new_tokens=100)[0].tolist())
print(output)
print("=" * 50)
print("🎉 مبروك يا مهندس يوسف الباز! نموذجك الأول تم تدريبه بنجاح.")
""".trimIndent()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = SleekCardBg),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SleekEmerald)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(SleekEmerald),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("تدريب النموذج عملياً على Google Colab", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SleekTextWhite)
              Text("خطوات تشغيل كود المهندس يوسف الباز بنقرة واحدة", fontSize = 10.sp, color = SleekEmeraldLight)
            }
          }
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "Google Colab هو كمبيوتر خارق ومجاني من جوجل يتيح لك تشغيل وتدريب نماذج الذكاء الاصطناعي مباشرة من متصفح هاتفك دون الحاجة لجهاز كمبيوتر.",
            fontSize = 11.sp,
            color = SleekTextSlate300,
            lineHeight = 16.sp
          )
        }
      }
    }

    item {
      Button(
        onClick = { copyToClipboard(fullColabScript, "كود التدريب الكامل لـ Colab") },
        colors = ButtonDefaults.buttonColors(containerColor = SleekEmerald),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
      ) {
        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color.Black, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("📋 نسخ كود التدريب الكامل (USUF-0.01)", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color(0xFF1F2937))
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("طريقة التشغيل السريعة من هاتفك:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
          Text("1️⃣ افتح المتصفح وادخل على: colab.research.google.com", fontSize = 11.sp, color = SleekTextSlate400)
          Text("2️⃣ اضغط على 'New Notebook' (دفتر ملاحظات جديد).", fontSize = 11.sp, color = SleekTextSlate400)
          Text("3️⃣ اضغط زر النسخ الأخضر أعلاه، ثم الصق الكود داخل الخلية في Colab.", fontSize = 11.sp, color = SleekTextSlate400)
          Text("4️⃣ اضغط على زر التشغيل ▶️ على يسار الخلية وانتظر انتهاء التدريب!", fontSize = 11.sp, color = SleekEmeraldLight, fontWeight = FontWeight.Bold)
        }
      }
    }

    item {
      CodeCard(
        title = "معاينة كود التدريب (PyTorch Standalone Script)",
        code = fullColabScript.take(600) + "\n\n# ... باقي الكود الكامل ينسخ بضغطة الزر بالأعلى ...",
        onCopy = { copyToClipboard(fullColabScript, "كود التدريب الكامل لـ Colab") }
      )
    }
  }
}

@Composable
fun CodeCard(title: String, code: String, onCopy: () -> Unit) {
  Card(
    colors = CardDefaults.cardColors(containerColor = SleekCardBg),
    shape = RoundedCornerShape(14.dp),
    border = BorderStroke(1.dp, SleekWhiteBorder)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(text = title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = SleekTextWhite)
        IconButton(onClick = onCopy, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = SleekEmerald, modifier = Modifier.size(16.dp))
        }
      }
      Spacer(modifier = Modifier.height(6.dp))
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(SleekBg)
          .border(BorderStroke(1.dp, Color(0x33334155)), RoundedCornerShape(8.dp))
          .padding(10.dp)
      ) {
        Text(
          text = code,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace,
          color = SleekEmeraldLight
        )
      }
    }
  }
}
