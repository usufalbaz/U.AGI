package com.example

data class ChatMessage(
  val id: String,
  val sender: String, // "user" or "assistant"
  val text: String,
  val timestamp: String = "الآن",
  val tokensCount: Int = 0,
  val imageUri: String? = null
)
