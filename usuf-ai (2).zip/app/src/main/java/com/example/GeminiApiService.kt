package com.example

import android.content.Context
import android.net.Uri
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiApiService {
  private const val TAG = "GeminiApiService"
  private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

  private val client = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(30, TimeUnit.SECONDS)
    .build()

  // Primary model candidates in order of preference
  val AVAILABLE_MODELS = listOf(
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite-preview",
    "gemini-flash-latest"
  )

  private const val PREFS_NAME = "usuf_ai_prefs"
  private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"
  private const val KEY_SELECTED_MODEL = "selected_gemini_model"

  fun getApiKey(context: Context): String {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val customKey = prefs.getString(KEY_CUSTOM_API_KEY, null)
    if (!customKey.isNullOrBlank()) {
      return customKey.trim()
    }
    // Fallback to BuildConfig key if defined and not default placeholder
    val buildConfigKey = try {
      val key = com.example.BuildConfig.GEMINI_API_KEY
      if (key.isNotBlank() && key != "MY_GEMINI_API_KEY") key else ""
    } catch (e: Exception) {
      ""
    }
    return buildConfigKey
  }

  fun saveApiKey(context: Context, key: String) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().putString(KEY_CUSTOM_API_KEY, key.trim()).apply()
  }

  fun getSelectedModel(context: Context): String {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return prefs.getString(KEY_SELECTED_MODEL, AVAILABLE_MODELS[0]) ?: AVAILABLE_MODELS[0]
  }

  fun setSelectedModel(context: Context, model: String) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().putString(KEY_SELECTED_MODEL, model).apply()
  }

  suspend fun askGemini(
    context: Context,
    history: List<ChatMessage>,
    newPrompt: String,
    enableWebGrounding: Boolean = false,
    imageBase64: String? = null,
    imageMimeType: String? = null
  ): Result<String> = withContext(Dispatchers.IO) {
    val apiKey = getApiKey(context)
    if (apiKey.isBlank()) {
      return@withContext Result.failure(
        IllegalStateException("لم يتم العثور على مفتاح API. يرجى إدخال مفتاح Gemini API من زر الإعدادات ⚙️ أعلى الشاشة.")
      )
    }

    val preferredModel = getSelectedModel(context)
    val modelsToTry = listOf(preferredModel) + (AVAILABLE_MODELS - preferredModel)

    var lastException: Exception? = null

    for (model in modelsToTry) {
      try {
        val reply = executeRequest(apiKey, model, history, newPrompt, enableWebGrounding, imageBase64, imageMimeType)
        return@withContext Result.success(reply)
      } catch (e: Exception) {
        Log.w(TAG, "Request failed for model $model (web=$enableWebGrounding): ${e.message}")
        lastException = e
        // If web grounding failed with quota (429), retry without web grounding
        if (enableWebGrounding && (e.message?.contains("quota") == true || e.message?.contains("429") == true)) {
          try {
            val fallbackReply = executeRequest(apiKey, model, history, newPrompt, false, imageBase64, imageMimeType)
            return@withContext Result.success(fallbackReply)
          } catch (retryEx: Exception) {
            lastException = retryEx
          }
        }
        if (e.message?.contains("API_KEY_INVALID") == true || e.message?.contains("403") == true) {
          break
        }
      }
    }

    Result.failure(lastException ?: Exception("تعذر الاتصال بخادم الذكاء الاصطناعي. يرجى المحاولة مرة أخرى."))
  }

  private fun executeRequest(
    apiKey: String,
    model: String,
    history: List<ChatMessage>,
    newPrompt: String,
    enableWebGrounding: Boolean,
    imageBase64: String? = null,
    imageMimeType: String? = null
  ): String {
    val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

    val requestJson = JSONObject().apply {
      // System instructions for USUF AI persona
      val systemInstructionObj = JSONObject().apply {
        val partsArr = JSONArray().apply {
          put(JSONObject().apply {
            put(
              "text",
              "أنت USUF AI - نموذج ذكاء اصطناعي عام (AGI) فائق التطور يحاكي تجربة وقدرات ChatGPT بالكامل، " +
                  "مطور كمنظومة ذكية للمهندس يوسف الباز (Eng. Yousuf Albaz). " +
                  "أنت عبقري في البرمجة، والرياضيات، والعلوم، والتاريخ، والأدب، وحل المشكلات الهندسية المعقدة. " +
                  "تحدث بأسلوب راقٍ واحترافي ودقيق. استخدم اللغة العربية الفصحى بطلاقة والمصطلحات التقنية والإنجليزية عند كتابة الأكواد. " +
                  "نظم إجاباتك بنقاط واضحة وتنسيق Markdown احترافي، وضع الأكواد داخل كتل برمجية واضحة."
            )
          })
        }
        put("parts", partsArr)
      }
      put("systemInstruction", systemInstructionObj)

      // Tools: Web Search Grounding if requested
      if (enableWebGrounding) {
        val toolsArray = JSONArray().apply {
          put(JSONObject().apply {
            put("googleSearch", JSONObject())
          })
        }
        put("tools", toolsArray)
      }

      // Contents (Multi-turn conversation)
      val contentsArray = JSONArray()

      // Include recent conversation context (last 10 messages)
      val recentMessages = history.takeLast(10)
      for (msg in recentMessages) {
        val role = if (msg.sender == "user") "user" else "model"
        val contentObj = JSONObject().apply {
          put("role", role)
          val parts = JSONArray().apply {
            put(JSONObject().apply { put("text", msg.text) })
          }
          put("parts", parts)
        }
        contentsArray.put(contentObj)
      }

      // Add the new user message
      val currentMsgObj = JSONObject().apply {
        put("role", "user")
        val parts = JSONArray().apply {
          if (!imageBase64.isNullOrBlank() && !imageMimeType.isNullOrBlank()) {
            put(JSONObject().apply {
              put("inlineData", JSONObject().apply {
                put("mimeType", imageMimeType)
                put("data", imageBase64)
              })
            })
          }
          val textPrompt = if (newPrompt.isNotBlank()) newPrompt else "حلل هذه الصورة بالتفصيل واشرح ما تحتويه."
          put(JSONObject().apply { put("text", textPrompt) })
        }
        put("parts", parts)
      }
      contentsArray.put(currentMsgObj)

      put("contents", contentsArray)

      // Generation config
      val config = JSONObject().apply {
        put("temperature", 0.7)
        put("maxOutputTokens", 2048)
      }
      put("generationConfig", config)
    }

    val requestBody = requestJson.toString().toRequestBody(JSON_MEDIA_TYPE)
    val request = Request.Builder()
      .url(url)
      .post(requestBody)
      .build()

    val response = client.newCall(request).execute()
    val responseBodyStr = response.body?.string().orEmpty()

    if (!response.isSuccessful) {
      val errorMsg = try {
        val errObj = JSONObject(responseBodyStr).optJSONObject("error")
        errObj?.optString("message") ?: "HTTP ${response.code}"
      } catch (e: Exception) {
        "HTTP ${response.code}: $responseBodyStr"
      }
      throw RuntimeException("خطأ في الخادم ($model): $errorMsg")
    }

    // Parse candidate text
    val jsonResponse = JSONObject(responseBodyStr)
    val candidates = jsonResponse.optJSONArray("candidates")
    if (candidates != null && candidates.length() > 0) {
      val firstCandidate = candidates.getJSONObject(0)
      val content = firstCandidate.optJSONObject("content")
      val parts = content?.optJSONArray("parts")
      if (parts != null && parts.length() > 0) {
        val textBuilder = StringBuilder()
        for (i in 0 until parts.length()) {
          val part = parts.getJSONObject(i)
          val t = part.optString("text", "")
          if (t.isNotBlank()) textBuilder.append(t)
        }
        if (textBuilder.isNotBlank()) {
          return textBuilder.toString()
        }
      }
    }

    return "لم يتم استلام أي نص من النموذج."
  }

  fun uriToBase64(context: Context, uri: Uri): Pair<String, String>? {
    return try {
      val cr = context.contentResolver
      val mimeType = cr.getType(uri) ?: "image/jpeg"
      val inputStream = cr.openInputStream(uri) ?: return null
      val bytes = inputStream.readBytes()
      inputStream.close()
      val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
      Pair(base64, mimeType)
    } catch (e: Exception) {
      Log.e(TAG, "Error encoding image to base64: ${e.message}")
      null
    }
  }
}
