package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Theme Palette (Deep Slate & Emerald Glow)
val SleekBg = Color(0xFF020617)
val SleekHeaderBg = Color(0xFF020617)
val SleekCardBg = Color(0xFF0A101F)
val SleekCardBorder = Color(0x1F38BDF8) // subtle border or white/10
val SleekWhiteBorder = Color(0x14FFFFFF) // border-white/5 ~ white/8
val SleekSubItemBg = Color(0x331E293B)
val SleekSubItemBorder = Color(0x4D334155)

val SleekEmerald = Color(0xFF10B981)
val SleekEmeraldLight = Color(0xFF34D399)
val SleekIndigo = Color(0xFF4F46E5)
val SleekViolet = Color(0xFF7C3AED)

val SleekTextWhite = Color(0xFFFFFFFF)
val SleekTextSlate300 = Color(0xFFCBD5E1)
val SleekTextSlate400 = Color(0xFF94A3B8)
val SleekTextSlate500 = Color(0xFF64748B)
val SleekTextSlate600 = Color(0xFF475569)

val SleekNavBg = Color(0xFF020617)
val SleekNavBorder = Color(0xFF1E293B)

// Compatibility aliases
val UsufPrimary = SleekEmeraldLight
val UsufSecondary = SleekIndigo
val UsufTertiary = SleekEmerald
val UsufDarkBackground = SleekBg
val UsufDarkSurface = SleekCardBg
val UsufDarkSurfaceVariant = Color(0xFF0F172A)
val UsufBorder = SleekWhiteBorder

val Purple80 = SleekEmeraldLight
val PurpleGrey80 = SleekIndigo
val Pink80 = SleekViolet

val Purple40 = SleekIndigo
val PurpleGrey40 = SleekViolet
val Pink40 = SleekEmerald
