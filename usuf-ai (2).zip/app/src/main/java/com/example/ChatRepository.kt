package com.example

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ChatSession(
  val id: String,
  val title: String,
  val updatedAt: Long,
  val messages: List<ChatMessage>
)

object ChatRepository {
  private const val PREFS_NAME = "usuf_gpt_sessions"
  private const val KEY_SESSIONS = "saved_sessions_json"
  private const val KEY_ACTIVE_SESSION_ID = "active_session_id"

  fun getAllSessions(context: Context): List<ChatSession> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val jsonStr = prefs.getString(KEY_SESSIONS, null) ?: return defaultSessions()

    return try {
      val array = JSONArray(jsonStr)
      val list = mutableListOf<ChatSession>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        val id = obj.getString("id")
        val title = obj.getString("title")
        val updatedAt = obj.getLong("updatedAt")
        val msgsArray = obj.getJSONArray("messages")
        val msgs = mutableListOf<ChatMessage>()
        for (j in 0 until msgsArray.length()) {
          val m = msgsArray.getJSONObject(j)
          msgs.add(
            ChatMessage(
              id = m.getString("id"),
              sender = m.getString("sender"),
              text = m.getString("text"),
              timestamp = m.optString("timestamp", "Now"),
              tokensCount = m.optInt("tokensCount", 0),
              imageUri = if (m.has("imageUri")) m.getString("imageUri") else null
            )
          )
        }
        list.add(ChatSession(id, title, updatedAt, msgs))
      }
      if (list.isEmpty()) defaultSessions() else list.sortedByDescending { it.updatedAt }
    } catch (e: Exception) {
      defaultSessions()
    }
  }

  fun saveSession(context: Context, session: ChatSession) {
    val current = getAllSessions(context).toMutableList()
    val idx = current.indexOfFirst { it.id == session.id }
    if (idx >= 0) {
      current[idx] = session
    } else {
      current.add(0, session)
    }
    persistSessions(context, current)
  }

  fun deleteSession(context: Context, sessionId: String): List<ChatSession> {
    val current = getAllSessions(context).filterNot { it.id == sessionId }
    persistSessions(context, current)
    return current
  }

  fun createNewSession(): ChatSession {
    val newId = System.currentTimeMillis().toString()
    return ChatSession(
      id = newId,
      title = "محادثة جديدة",
      updatedAt = System.currentTimeMillis(),
      messages = emptyList()
    )
  }

  fun renameSession(context: Context, sessionId: String, newTitle: String) {
    val current = getAllSessions(context).map {
      if (it.id == sessionId) it.copy(title = newTitle.trim()) else it
    }
    persistSessions(context, current)
  }

  fun getActiveSessionId(context: Context): String? {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return prefs.getString(KEY_ACTIVE_SESSION_ID, null)
  }

  fun setActiveSessionId(context: Context, sessionId: String) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().putString(KEY_ACTIVE_SESSION_ID, sessionId).apply()
  }

  private fun persistSessions(context: Context, sessions: List<ChatSession>) {
    val array = JSONArray()
    for (s in sessions) {
      val obj = JSONObject().apply {
        put("id", s.id)
        put("title", s.title)
        put("updatedAt", s.updatedAt)
        val msgsArray = JSONArray()
        for (m in s.messages) {
          msgsArray.put(
            JSONObject().apply {
              put("id", m.id)
              put("sender", m.sender)
              put("text", m.text)
              put("timestamp", m.timestamp)
              put("tokensCount", m.tokensCount)
              if (m.imageUri != null) put("imageUri", m.imageUri)
            }
          )
        }
        put("messages", msgsArray)
      }
      array.put(obj)
    }
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit().putString(KEY_SESSIONS, array.toString()).apply()
  }

  private fun defaultSessions(): List<ChatSession> {
    return listOf(
      ChatSession(
        id = "default_1",
        title = "مرحباً بك في USUF AI (GPT)",
        updatedAt = System.currentTimeMillis(),
        messages = listOf(
          ChatMessage(
            id = "init_1",
            sender = "assistant",
            text = "أهلاً بك يا مهندس يوسف في USUF AI! 🚀\n" +
                "أنا نموذج ذكاء اصطناعي عام متقدم، مصمم ليكون مثل ChatGPT تماماً في كل شيء. " +
                "يمكنني مساعدتك في كتابة وبرمجة المشاريع، وتطوير معمارية النماذج العصبية، والبحث في المعلومات، والتحليل المنطقي. كيف أساعدك اليوم؟",
            tokensCount = 35
          )
        )
      )
    )
  }
}
