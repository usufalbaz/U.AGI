package com.example

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object TtsManager {
  private var tts: TextToSpeech? = null
  private var isInitialized = false

  fun init(context: Context) {
    if (tts == null) {
      tts = TextToSpeech(context.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
          isInitialized = true
          // Try to set Arabic or fallback to default
          val result = tts?.setLanguage(Locale("ar"))
          if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
          }
        }
      }
    }
  }

  fun toggleSpeak(text: String, context: Context) {
    init(context)
    val engine = tts ?: return
    if (engine.isSpeaking) {
      engine.stop()
    } else {
      // Clean markdown symbols for natural speech
      val cleanedText = text
        .replace("```[a-zA-Z0-9_-]*".toRegex(), "")
        .replace("```", "")
        .replace("#", "")
        .replace("*", "")
      engine.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, null, "usuf_ai_tts")
    }
  }

  fun stop() {
    tts?.stop()
  }
}
