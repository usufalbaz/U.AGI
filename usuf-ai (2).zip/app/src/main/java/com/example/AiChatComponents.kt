package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun AiSettingsDialog(
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  var currentKey by remember { mutableStateOf(GeminiApiService.getApiKey(context)) }
  var selectedModel by remember { mutableStateOf(GeminiApiService.getSelectedModel(context)) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = SleekCardBg,
      border = BorderStroke(1.dp, Color(0xFF334155)),
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.Psychology,
              contentDescription = null,
              tint = SleekEmerald,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "إعدادات ذكاء USUF AI",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
        }

        Divider(color = Color(0xFF1E293B))

        // Model Selector
        Text(
          text = "نموذج الذكاء الاصطناعي (Model):",
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          color = SleekTextSlate400
        )

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          GeminiApiService.AVAILABLE_MODELS.forEach { model ->
            val isSelected = selectedModel == model
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) Color(0xFF1E293B) else Color(0xFF0F172A),
              border = BorderStroke(1.dp, if (isSelected) SleekEmerald else Color(0xFF334155)),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { selectedModel = model }
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = model,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) SleekEmeraldLight else Color.White
                  )
                  Text(
                    text = when (model) {
                      "gemini-3.5-flash" -> "استنتاج وتفكير منطقي فائق (موصى به)"
                      "gemini-3.1-flash-lite-preview" -> "استجابة سريعة وخفيفة للغاية"
                      else -> "النموذج القياسي المتوازن"
                    },
                    fontSize = 10.sp,
                    color = SleekTextSlate400
                  )
                }
                if (isSelected) {
                  Icon(
                    Icons.Default.Check,
                    contentDescription = null,
                    tint = SleekEmerald,
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
            }
          }
        }

        // API Key Section
        Text(
          text = "مفتاح Gemini API Key:",
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          color = SleekTextSlate400
        )

        OutlinedTextField(
          value = currentKey,
          onValueChange = { currentKey = it },
          modifier = Modifier.fillMaxWidth(),
          placeholder = { Text("الصق مفتاح API هنا...", fontSize = 11.sp, color = SleekTextSlate500) },
          shape = RoundedCornerShape(10.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = SleekEmerald,
            unfocusedBorderColor = Color(0xFF334155),
            focusedContainerColor = Color(0xFF0F172A),
            unfocusedContainerColor = Color(0xFF0F172A)
          ),
          singleLine = true
        )

        Text(
          text = "💡 يتم حفظ المفتاح محلياً على جهازك بأمان ويستخدم لمخاطبة النموذج مباشرة.",
          fontSize = 10.sp,
          color = SleekTextSlate500,
          lineHeight = 14.sp
        )

        // Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically
        ) {
          TextButton(onClick = onDismiss) {
            Text("إلغاء", color = SleekTextSlate400, fontSize = 12.sp)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              GeminiApiService.saveApiKey(context, currentKey)
              GeminiApiService.setSelectedModel(context, selectedModel)
              Toast.makeText(context, "تم حفظ الإعدادات بنجاح!", Toast.LENGTH_SHORT).show()
              onDismiss()
            },
            colors = ButtonDefaults.buttonColors(containerColor = SleekEmerald),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("حفظ", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        }
      }
    }
  }
}

@Composable
fun FormattedMessageContent(
  text: String,
  isUser: Boolean,
  onCopyCode: (String) -> Unit
) {
  // Simple code block splitter for ```code```
  val parts = remember(text) {
    val regex = "```([a-zA-Z0-9_-]*)\\n?([\\s\\S]*?)```".toRegex()
    val matches = regex.findAll(text).toList()

    if (matches.isEmpty()) {
      listOf(MessagePart.PlainText(text))
    } else {
      val result = mutableListOf<MessagePart>()
      var lastIdx = 0
      for (match in matches) {
        if (match.range.first > lastIdx) {
          result.add(MessagePart.PlainText(text.substring(lastIdx, match.range.first)))
        }
        val lang = match.groupValues[1].ifBlank { "CODE" }
        val code = match.groupValues[2]
        result.add(MessagePart.CodeBlock(lang.uppercase(), code.trimEnd()))
        lastIdx = match.range.last + 1
      }
      if (lastIdx < text.length) {
        result.add(MessagePart.PlainText(text.substring(lastIdx)))
      }
      result
    }
  }

  Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    for (part in parts) {
      when (part) {
        is MessagePart.PlainText -> {
          if (part.content.isNotBlank()) {
            Text(
              text = part.content.trim(),
              fontSize = 12.sp,
              color = Color.White,
              lineHeight = 19.sp
            )
          }
        }
        is MessagePart.CodeBlock -> {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFF030712))
              .border(BorderStroke(1.dp, Color(0xFF1F2937)), RoundedCornerShape(8.dp))
          ) {
            // Code Header
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF111827))
                .padding(horizontal = 10.dp, vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = part.language,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = SleekEmeraldLight,
                fontFamily = FontFamily.Monospace
              )
              Row(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .clickable { onCopyCode(part.code) }
                  .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.ContentCopy,
                  contentDescription = "Copy code",
                  tint = SleekTextSlate400,
                  modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "نسخ الكود",
                  fontSize = 9.sp,
                  color = SleekTextSlate400
                )
              }
            }

            // Code Content
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(10.dp)
            ) {
              Text(
                text = part.code,
                fontSize = 11.sp,
                color = Color(0xFFA7F3D0),
                fontFamily = FontFamily.Monospace,
                lineHeight = 16.sp
              )
            }
          }
        }
      }
    }
  }
}

sealed class MessagePart {
  data class PlainText(val content: String) : MessagePart()
  data class CodeBlock(val language: String, val code: String) : MessagePart()
}
