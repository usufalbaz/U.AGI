"""
USUF AI - Phase 0 Foundation Unit Tests
Validates repository structure, configuration files, model calculations, and hardware adaptation.
Executable with standard python3 unittest or pytest.
"""
import os
import unittest
from model.config import get_model_config, USUFModelConfig
from training.device import detect_hardware

try:
    import yaml
except ImportError:
    yaml = None


class TestPhase0Foundation(unittest.TestCase):

    def test_directory_structure(self):
        """Verify all mandatory directories exist in repository."""
        required_dirs = [
            "configs",
            "data",
            "data/raw",
            "data/cleaned",
            "data/filtered",
            "data/deduplicated",
            "data/train",
            "data/validation",
            "data/test",
            "tokenizer",
            "model",
            "training",
            "notebooks",
            "docs",
            "tests",
        ]
        for d in required_dirs:
            self.assertTrue(os.path.exists(d), f"Directory missing: {d}")

    def test_yaml_configurations_exist_and_non_empty(self):
        """Verify that all YAML configs exist and contain valid definitions."""
        config_files = [
            "configs/tokenizer.yaml",
            "configs/model.yaml",
            "configs/training.yaml",
            "configs/evaluation.yaml",
        ]
        for cfg in config_files:
            self.assertTrue(os.path.exists(cfg), f"Config missing: {cfg}")
            self.assertGreater(os.path.getsize(cfg), 50, f"Config file {cfg} is too small or empty")
            if yaml is not None:
                with open(cfg, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)
                    self.assertIsNotNone(data, f"Config {cfg} parsed as empty")

    def test_model_config_usuf_0_01(self):
        """Verify USUF-0.01 parameters count calculation (~1.8M params)."""
        cfg = get_model_config("configs/model.yaml", variant="usuf_0_01")
        self.assertEqual(cfg.name, "USUF-0.01")
        self.assertEqual(cfg.vocab_size, 32000)
        self.assertEqual(cfg.hidden_size, 192)
        self.assertEqual(cfg.num_layers, 4)
        self.assertEqual(cfg.num_heads, 6)
        self.assertEqual(cfg.head_dim, 32)

        params = cfg.estimate_parameter_count()
        self.assertGreater(params["total_params"], 1_000_000, "USUF-0.01 must exceed 1M params")
        self.assertLess(params["total_params"], 10_000_000, "USUF-0.01 should remain under 10M params")

    def test_model_config_usuf_1(self):
        """Verify USUF-1 flagship model config calculation (~130M params)."""
        cfg = get_model_config("configs/model.yaml", variant="usuf_1")
        self.assertEqual(cfg.name, "USUF-1")
        self.assertEqual(cfg.hidden_size, 768)
        self.assertEqual(cfg.num_layers, 24)
        self.assertEqual(cfg.num_heads, 12)

        params = cfg.estimate_parameter_count()
        self.assertGreater(params["total_params"], 100_000_000, "USUF-1 should be ~100M+ params")

    def test_hardware_profiler(self):
        """Verify hardware profiler returns valid device and memory stats."""
        profile = detect_hardware()
        self.assertIn(profile.device_type, ["cuda", "cpu"])
        self.assertGreater(profile.ram_gb, 0)
        self.assertGreater(profile.cpu_cores, 0)
        self.assertGreater(profile.recommended_micro_batch, 0)
        self.assertGreater(profile.recommended_grad_accum, 0)


if __name__ == "__main__":
    unittest.main()
