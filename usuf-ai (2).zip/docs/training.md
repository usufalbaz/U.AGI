# USUF AI Training Mechanics & Science

## Pretraining Objective
USUF-1 is trained with standard **Autoregressive Causal Next-Token Prediction**:
$$\mathcal{L}_{LLM}(\theta) = -\sum_{t=1}^T \log P_\theta(x_t \mid x_{<t})$$

The loss is Cross-Entropy over vocabulary logits, with validation perplexity defined as:
$$\text{PPL} = \exp(\mathcal{L}_{val})$$

## Mathematical Foundations of the Training Pipeline

### 1. Mixed Precision (FP16 / BF16)
- **Forward Pass:** Performed in FP16 or BF16 to halve activation memory and quadruple Tensor Core throughput.
- **Master Weights:** Kept in FP32 inside AdamW to prevent underflow in small gradient updates.
- **GradScaler:** Manages dynamic loss scaling to avoid gradient underflow in FP16 on Colab Tesla T4.

### 2. Gradient Accumulation
When Colab GPU VRAM limits micro-batch size to $B_{micro} = 8$, we accumulate gradients over $K = 8$ steps before calling `optimizer.step()`:
$$B_{effective} = B_{micro} \times K = 64 \text{ sequences}$$
This provides stable optimizer trajectories without triggering CUDA Out-Of-Memory (OOM).

### 3. AdamW Optimizer
$$\theta_{t+1} = \theta_t - \eta_t \left( \frac{\hat{m}_t}{\sqrt{\hat{v}_t} + \epsilon} + \lambda \theta_t \right)$$
- Weight decay $\lambda = 0.1$ applied directly to weights, decoupled from moving gradient averages.
- Beta parameters: $\beta_1 = 0.9, \beta_2 = 0.95$.

### 4. Cosine Learning Rate Schedule with Warmup
Learning rate linearly ramps up for 200–500 steps to prevent unstable updates during early random initialization, then follows a cosine decay toward $\eta_{min} = 0.1 \times \eta_{max}$.

### 5. Checkpointing & Atomic State Restoration
Every 500 steps, a snapshot is saved containing:
- `model_state_dict`
- `optimizer_state_dict`
- `scheduler_state_dict`
- `step`, `epoch`, `metrics`
- System RNG states (`torch`, `cuda`, `numpy`, `random`)
This enables restarting training in Google Colab from the exact micro-state without losing training progress.
