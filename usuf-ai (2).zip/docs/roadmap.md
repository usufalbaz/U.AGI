# USUF AI Development Roadmap (Phases 0 through 12)

## Strict Sequential Development Policy
Each phase has clear exit criteria. No phase is skipped or rushed.

| Phase | Title | Objective | Deliverables | Status |
| :--- | :--- | :--- | :--- | :--- |
| **PHASE 0** | **Project Foundation** | Complete architecture, configs, tests foundation, Colab notebooks, mobile control center | Repos, configs, docs, tests, Colab skeletons | **ACTIVE** |
| **PHASE 1** | **Tokenizer From Scratch** | Train Byte-Level BPE (32k vocab) on Arabic, English, Code, Math | `tokenizer.json`, encode/decode utils, OOV tests | Planned |
| **PHASE 2** | **Dataset Pipeline** | Clean, filter, deduplicate, and split legal open datasets | 7-stage data scripts, quality report generator | Planned |
| **PHASE 3** | **Tiny Transformer Architecture** | Decoder-only Transformer in pure PyTorch with RoPE, RMSNorm, SwiGLU | Forward/backward unit tests, gradient flow checks | Planned |
| **PHASE 4** | **USUF-0.01 Pretraining** | Proof of Concept (~1.8M params) pretraining on Colab | Loss convergence, perplexity drop, checkpointing | Planned |
| **PHASE 5** | **Evaluation System** | Automated loss, PPL, and multilingual benchmarks | `evaluate.py`, `USUF_Evaluation.ipynb` | Planned |
| **PHASE 6** | **USUF-0.1 Scaling** | Scale model to ~15M params on Colab GPU | Checkpoints, scaling curves, syntax learning | Planned |
| **PHASE 7** | **Instruction Tuning (SFT)** | Supervised fine-tuning pipeline on instruction datasets | Prompt-response pairs, Alpaca/Chat formatting | Planned |
| **PHASE 8** | **USUF-1-Chat** | Conversational chat model with System/User/Assistant template | Multi-turn chat loop, stop tokens | Planned |
| **PHASE 9** | **Inference Engine** | High-performance generation with sampling, top-k/p, repetition penalty | `generate.py`, streaming token generation | Planned |
| **PHASE 10** | **Web / Mobile Interface** | Mobile-first modern UI with chat & metrics telemetry | Interactive Chat UI, model specs, stats viewer | Planned |
| **PHASE 11** | **USUF Agent Layer** | External tool calling, calculator, Python code execution layer | Agent controller, tool schemas, safe execution | Planned |
| **PHASE 12** | **Scaling & Flagship USUF-1** | Scaling to USUF-0.5 and USUF-1 base targets | Production checkpoints, model card, export | Planned |
