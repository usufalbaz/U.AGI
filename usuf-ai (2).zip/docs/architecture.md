# USUF AI Architecture Specification

## Overview
USUF-1 is a modern **Decoder-Only Autoregressive Transformer** built from the ground up without borrowing or inheriting pretrained weights from third-party models (Gemini, GPT, Claude, Llama). Every weight parameter is initialized from a calibrated normal distribution ($\mathcal{N}(0, 0.02)$) and learned via pretraining.

## Architectural Components

```
                    ┌───────────────────────────┐
                    │       Output Logits       │
                    └─────────────▲─────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │      RMSNorm (Final)      │
                    └─────────────▲─────────────┘
                                  │
                  ┌───────────────┴───────────────┐
                  │   Transformer Block × N       │
                  │  ┌─────────────────────────┐  │
                  │  │     SwiGLU MLP          │  │
                  │  │  (Gate, Up, Down Proj)  │  │
                  │  └────────────▲────────────┘  │
                  │               ┼ Residual      │
                  │  ┌────────────┴────────────┐  │
                  │  │       RMSNorm 2         │  │
                  │  └────────────▲────────────┘  │
                  │               │               │
                  │  ┌────────────┴────────────┐  │
                  │  │  Causal Self-Attention  │  │
                  │  │       + RoPE            │  │
                  │  └────────────▲────────────┘  │
                  │               ┼ Residual      │
                  │  ┌────────────┴────────────┐  │
                  │  │       RMSNorm 1         │  │
                  │  └────────────▲────────────┘  │
                  └───────────────┬───────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │     Token Embeddings      │
                    └─────────────▲─────────────┘
                                  │
                           Input Token IDs
```

### 1. Token Embeddings & Weight Tying
- **Vocabulary Size:** 32,000 tokens (Arabic, English, Code, Math, Special Tokens).
- **Weight Tying:** The embedding matrix is shared with the output projection language modeling head (`tie_word_embeddings = true`). This saves ~24.5M parameters in a 768-dim model and improves representation alignment.

### 2. Rotary Position Embeddings (RoPE)
Instead of static learned absolute positional encodings, USUF uses RoPE. RoPE encodes relative positional distance directly into query ($Q$) and key ($K$) dot products:
$$R_{\Theta, m}^d = \text{diag}(R_{\theta_1, m}, \dots, R_{\theta_{d/2}, m})$$
This allows the attention mechanism to naturally scale and generalize to arbitrary sequence lengths.

### 3. Pre-Normalization with RMSNorm
We replace standard LayerNorm with Root Mean Square Normalization (RMSNorm):
$$\text{RMSNorm}(x) = \frac{x}{\sqrt{\frac{1}{d}\sum_{i=1}^d x_i^2 + \epsilon}} \odot \gamma$$
This eliminates mean-centering computation, saving ~15% memory bandwidth per layer while preserving training stability.

### 4. SwiGLU Feed-Forward Network
Instead of standard ReLU or GELU activations, USUF adopts SwiGLU (Swish Gated Linear Unit):
$$\text{SwiGLU}(x) = (\text{swish}(x W_{gate}) \odot x W_{up}) W_{down}$$
where $\text{swish}(x) = x \cdot \sigma(x)$. Intermediate dimension is sized to $\approx \frac{8}{3} d_{model}$.

## Model Scale Matrix

| Model | Hidden Size | Layers | Heads | Head Dim | Context | Est. Params | Colab Target |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **USUF-0.01** | 192 | 4 | 6 | 32 | 256 | ~1.8M | Free CPU / T4 (Minutes) |
| **USUF-0.1** | 384 | 8 | 6 | 64 | 512 | ~15M | Free T4 GPU (Hours) |
| **USUF-0.5** | 576 | 16 | 8 | 72 | 1024 | ~60M | T4 / A100 GPU |
| **USUF-1** | 768 | 24 | 12 | 64 | 2048 | ~130M | Dedicated Cloud GPU |
