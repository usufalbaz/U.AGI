# USUF AI Data Pipeline Guidelines

## Structure & Separation of Concerns
This directory manages data preparation across 7 verified stages. **No large raw datasets or binary corpus dumps are stored in Git.**

```
data/
├── raw/            # Stage 1: Downloaded open-source raw texts (Wikipedia, OpenSubtitles, ArWiki, GitHub open-license code)
├── cleaned/        # Stage 2: UTF-8 normalized, HTML/boilerplate stripped, encoding errors repaired
├── filtered/       # Stage 3: Quality heuristics (doc length, toxicity, non-linguistic noise removal)
├── deduplicated/   # Stage 4: MinHash / Exact hash deduplication to eliminate repeated pages
├── train/          # Stage 5: Training split (95%)
├── validation/     # Stage 6: Validation split (4%)
└── test/           # Stage 7: Held-out benchmark split (1%)
```

## Supported Domains
1. **Arabic Text:** Modern Standard Arabic literature, news, encyclopedic, and technical documentation.
2. **English Text:** Technical, scientific, and open educational materials.
3. **Programming Code:** Permissive open-license code (Python, JS, C++, SQL, HTML/CSS).
4. **Mathematics:** Equations, step-by-step arithmetic, and mathematical definitions.

## Quality Filters
- Document length: Min 20 tokens, max 8,192 tokens.
- Repetition ratio: Flag docs with >20% repeated n-grams.
- Language ID: FastText or heuristic regex ensuring Arabic, English, or Code content.
- Deduplication: Near-deduplication with MinHash LSH.
