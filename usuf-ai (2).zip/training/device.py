"""
USUF AI - Hardware Profiler & Dynamic Adaptation
Inspects Google Colab environment (CUDA, VRAM, RAM, CPU) and adapts training hyperparameters dynamically.
Ensures zero Out-Of-Memory (OOM) crashes across standard free tier and premium Colab GPUs.
"""
import os
from dataclasses import dataclass
from typing import Dict, Any, Tuple

try:
    import psutil
except ImportError:
    psutil = None

try:
    import torch
except ImportError:
    torch = None


@dataclass
class HardwareProfile:
    device_type: str  # "cuda" or "cpu"
    device_name: str
    vram_gb: float
    ram_gb: float
    cpu_cores: int
    recommended_precision: str
    recommended_micro_batch: int
    recommended_grad_accum: int


def detect_hardware() -> HardwareProfile:
    """Detects available hardware and recommends safe operational parameters."""
    if psutil is not None:
        ram_gb = round(psutil.virtual_memory().total / (1024 ** 3), 2)
    else:
        # Fallback reading from /proc/meminfo on Linux or 8GB default
        try:
            with open("/proc/meminfo", "r") as f:
                for line in f:
                    if "MemTotal" in line:
                        ram_gb = round(int(line.split()[1]) / (1024 ** 2), 2)
                        break
                else:
                    ram_gb = 8.0
        except Exception:
            ram_gb = 8.0

    cpu_cores = os.cpu_count() or 2

    if torch is not None and torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name(0)
        vram_bytes = torch.cuda.get_device_properties(0).total_memory
        vram_gb = round(vram_bytes / (1024 ** 3), 2)
        device_type = "cuda"

        # Determine precision: bfloat16 for modern GPUs (Ampere/Hopper/Ada), fp16 for older (T4/V100)
        compute_capability = torch.cuda.get_device_capability(0)
        if compute_capability[0] >= 8:
            precision = "bf16"
        else:
            precision = "fp16"

        # Adaptive batch sizing according to VRAM
        if vram_gb >= 24: # A100 / RTX 3090/4090
            micro_batch = 16
            grad_accum = 4
        elif vram_gb >= 14: # Colab Tesla T4 (~15GB) / V100
            micro_batch = 8
            grad_accum = 8
        elif vram_gb >= 8: # RTX 3070 / 8GB VRAM
            micro_batch = 4
            grad_accum = 16
        else:
            micro_batch = 2
            grad_accum = 32
    else:
        # Fallback to CPU execution
        gpu_name = "CPU Only (Google Colab Standard CPU Runtime)"
        vram_gb = 0.0
        device_type = "cpu"
        precision = "fp32"
        micro_batch = 2
        grad_accum = 16

    return HardwareProfile(
        device_type=device_type,
        device_name=gpu_name,
        vram_gb=vram_gb,
        ram_gb=ram_gb,
        cpu_cores=cpu_cores,
        recommended_precision=precision,
        recommended_micro_batch=micro_batch,
        recommended_grad_accum=grad_accum,
    )


def adapt_batch_config(base_config: dict, profile: HardwareProfile) -> dict:
    """Overwrites training config batch parameters with hardware-safe values."""
    cfg = dict(base_config)
    cfg["hardware"]["recommended_precision"] = profile.recommended_precision
    cfg["batching"]["micro_batch_size"] = profile.recommended_micro_batch
    cfg["batching"]["gradient_accumulation_steps"] = profile.recommended_grad_accum
    cfg["effective_batch_size"] = profile.recommended_micro_batch * profile.recommended_grad_accum
    return cfg


if __name__ == "__main__":
    profile = detect_hardware()
    print("=== USUF AI Hardware Profiler ===")
    print(f"Device: {profile.device_name} ({profile.device_type})")
    print(f"VRAM: {profile.vram_gb} GB | System RAM: {profile.ram_gb} GB | CPU Cores: {profile.cpu_cores}")
    print(f"Recommended Precision: {profile.recommended_precision}")
    print(f"Recommended Micro-Batch: {profile.recommended_micro_batch} | Grad Accumulation: {profile.recommended_grad_accum}")
    print(f"Effective Batch Size: {profile.recommended_micro_batch * profile.recommended_grad_accum}")
