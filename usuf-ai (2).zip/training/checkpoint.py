"""
USUF AI - Checkpoint Manager
Atomic serialization and restoration of model weights, optimizer, scheduler,
random states, and training metrics for fault-tolerant Colab training.
"""
import os
import glob
import json
import random
from typing import Optional, Dict, Any

try:
    import torch
    import numpy as np
except ImportError:
    torch = None
    np = None


class CheckpointManager:
    def __init__(self, save_dir: str = "checkpoints", keep_last_n: int = 3):
        self.save_dir = save_dir
        self.keep_last_n = keep_last_n
        os.makedirs(self.save_dir, exist_ok=True)

    def save(
        self,
        step: int,
        epoch: int,
        model: Any,
        optimizer: Any,
        scheduler: Any,
        config: Dict[str, Any],
        metrics: Dict[str, float]
    ) -> str:
        """Atomically saves checkpoint to disk."""
        if torch is None:
            raise ImportError("PyTorch required for saving checkpoints.")

        checkpoint_dir = os.path.join(self.save_dir, f"step_{step}")
        os.makedirs(checkpoint_dir, exist_ok=True)
        checkpoint_path = os.path.join(checkpoint_dir, "checkpoint.pt")
        temp_path = checkpoint_path + ".tmp"

        payload = {
            "step": step,
            "epoch": epoch,
            "model_state_dict": model.state_dict() if hasattr(model, "state_dict") else model,
            "optimizer_state_dict": optimizer.state_dict() if hasattr(optimizer, "state_dict") else optimizer,
            "scheduler_state_dict": scheduler.state_dict() if hasattr(scheduler, "state_dict") else scheduler,
            "config": config,
            "metrics": metrics,
            "rng_states": {
                "torch": torch.get_rng_state(),
                "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
                "numpy": np.random.get_state() if np is not None else None,
                "python": random.getstate(),
            }
        }

        # Atomic write
        torch.save(payload, temp_path)
        if os.path.exists(checkpoint_path):
            os.remove(checkpoint_path)
        os.rename(temp_path, checkpoint_path)

        # Save human-readable metrics metadata
        metrics_meta_path = os.path.join(checkpoint_dir, "metrics.json")
        with open(metrics_meta_path, "w", encoding="utf-8") as f:
            json.dump({"step": step, "epoch": epoch, "metrics": metrics}, f, indent=2)

        # Update latest pointer symlink/file
        latest_pointer = os.path.join(self.save_dir, "latest.txt")
        with open(latest_pointer, "w", encoding="utf-8") as f:
            f.write(checkpoint_path)

        self._cleanup_old_checkpoints()
        print(f"[✓] Checkpoint successfully saved for step {step} at: {checkpoint_path}")
        return checkpoint_path

    def load_latest(self) -> Optional[Dict[str, Any]]:
        """Finds and loads the latest checkpoint."""
        latest_pointer = os.path.join(self.save_dir, "latest.txt")
        if os.path.exists(latest_pointer):
            with open(latest_pointer, "r", encoding="utf-8") as f:
                path = f.read().strip()
                if os.path.exists(path):
                    return self.load(path)

        # Fallback: scan directory
        subdirs = glob.glob(os.path.join(self.save_dir, "step_*"))
        if not subdirs:
            return None

        # Sort by step number
        subdirs.sort(key=lambda x: int(os.path.basename(x).split("_")[1]))
        latest_path = os.path.join(subdirs[-1], "checkpoint.pt")
        if os.path.exists(latest_path):
            return self.load(latest_path)
        return None

    def load(self, checkpoint_path: str) -> Dict[str, Any]:
        """Loads checkpoint payload from file and restores RNG states."""
        if torch is None:
            raise ImportError("PyTorch required for loading checkpoints.")
        if not os.path.exists(checkpoint_path):
            raise FileNotFoundError(f"Checkpoint not found at: {checkpoint_path}")

        print(f"[*] Loading USUF checkpoint from: {checkpoint_path}")
        device = "cuda" if torch.cuda.is_available() else "cpu"
        payload = torch.load(checkpoint_path, map_location=device)

        # Restore RNG states for strict reproducibility
        if "rng_states" in payload:
            rng = payload["rng_states"]
            if rng.get("torch") is not None:
                torch.set_rng_state(rng["torch"])
            if rng.get("torch_cuda") is not None and torch.cuda.is_available():
                torch.cuda.set_rng_state_all(rng["torch_cuda"])
            if rng.get("numpy") is not None and np is not None:
                np.random.set_state(rng["numpy"])
            if rng.get("python") is not None:
                random.setstate(rng["python"])

        return payload

    def _cleanup_old_checkpoints(self):
        """Removes older checkpoints keeping only the last N."""
        subdirs = glob.glob(os.path.join(self.save_dir, "step_*"))
        if len(subdirs) <= self.keep_last_n:
            return

        subdirs.sort(key=lambda x: int(os.path.basename(x).split("_")[1]))
        to_delete = subdirs[:-self.keep_last_n]
        for d in to_delete:
            try:
                import shutil
                shutil.rmtree(d)
                print(f"[*] Cleaned up older checkpoint: {d}")
            except Exception as e:
                print(f"[!] Warning: Failed to clean up {d}: {e}")
