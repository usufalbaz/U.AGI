"""
USUF AI Training Utilities
Device hardware adaptation, checkpoint management, and state serialization.
"""
from .device import HardwareProfile, detect_hardware, adapt_batch_config
from .checkpoint import CheckpointManager

__all__ = ["HardwareProfile", "detect_hardware", "adapt_batch_config", "CheckpointManager"]
