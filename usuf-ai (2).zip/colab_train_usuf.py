"""
=============================================================================
             USUF AI - Transformer Training Script for Google Colab
             Project Owner & Lead Developer: Eng. Yousuf Albaz
=============================================================================
This is a self-contained PyTorch script to train a custom Decoder-Only
Transformer model (USUF-0.01) from scratch with ZERO external weights.
Run this script inside a single Google Colab cell.
"""

import os
import math
import time
import torch
import torch.nn as nn
import torch.nn.functional as F

print("=" * 60)
print("🚀 مرحباً بك يا مهندس يوسف الباز في معمل تدريب USUF AI")
print("=" * 60)

# 1. إعداد الجهاز (GPU أو CPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
if torch.cuda.is_available():
    print(f"✅ تم اكتشاف معالج الرسوميات بنجاح: {torch.cuda.get_device_name(0)}")
else:
    print("ℹ️ يعمل على المعالج CPU (يُفضل تفعيل T4 GPU من Runtime > Change runtime type)")

# 2. بيانات التدريب المصغرة (عربي + إنجليزي في علوم الذكاء الاصطناعي والبرمجة)
training_text = """
مرحباً بكم في مشروع USUF AI الخاص بالمهندس يوسف الباز.
الذكاء الاصطناعي العام هو تقنية تحاكي قدرات العقل البشري في الفهم والتحليل وحل المشكلات.
معمارية Transformer هي الأساس الذي بنيت عليه نماذج اللغة الكبيرة مثل GPT.
تعتمد المعمارية على آليات الانتباه الذاتي Self-Attention لحساب العلاقات بين الكلمات.
تقنية Rotary Position Embedding RoPE تستخدم لتدوير متجهات الاستعلام والمفتاح رياضياً.
دالة RMSNorm تضمن استقرار التدريب وتسريع التقارب العصبي.
دالة التنشيط SwiGLU توفر قدرة تمثيلية أعلى من دوال التنشيط التقليدية.
USUF AI is an advanced generative AI model designed by Engineer Yousuf Albaz.
Artificial General Intelligence represents the future of deep learning and neural computation.
Transformer decoders predict the next token given previous context using causal masking.
PyTorch provides tensor computation with strong GPU acceleration.
""" * 40

# 3. بناء Tokenizer مبسّط (Character-Level Tokenizer)
chars = sorted(list(set(training_text)))
vocab_size = len(chars)
char_to_id = {ch: i for i, ch in enumerate(chars)}
id_to_char = {i: ch for i, ch in enumerate(chars)}

def encode(text):
    return [char_to_id[c] for c in text if c in char_to_id]

def decode(tokens):
    return "".join([id_to_char[t] for t in tokens if t in id_to_char])

print(f"📊 حجم المفردات (Vocab Size): {vocab_size} رمز")

# تحويل النصوص إلى Tensors
data_tensor = torch.tensor(encode(training_text), dtype=torch.long)
n_train = int(0.9 * len(data_tensor))
train_data = data_tensor[:n_train]
val_data = data_tensor[n_train:]

# 4. معمارية نموذج USUF-0.01 (Transformer Decoder)
class RMSNorm(nn.Module):
    def __init__(self, dim, eps=1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        variance = x.pow(2).mean(-1, keepdim=True)
        return x * torch.rsqrt(variance + self.eps) * self.weight

class CausalSelfAttention(nn.Module):
    def __init__(self, hidden_size, num_heads):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.qkv_proj = nn.Linear(hidden_size, 3 * hidden_size, bias=False)
        self.out_proj = nn.Linear(hidden_size, hidden_size, bias=False)

    def forward(self, x):
        B, T, C = x.size()
        qkv = self.qkv_proj(x).chunk(3, dim=-1)
        q, k, v = [t.view(B, T, self.num_heads, self.head_dim).transpose(1, 2) for t in qkv]
        
        # Flash Attention / Scaled Dot-Product Attention
        out = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        out = out.transpose(1, 2).contiguous().view(B, T, C)
        return self.out_proj(out)

class SwiGLUMlp(nn.Module):
    def __init__(self, hidden_size, intermediate_size):
        super().__init__()
        self.w1 = nn.Linear(hidden_size, intermediate_size, bias=False) # Gate
        self.w2 = nn.Linear(hidden_size, intermediate_size, bias=False) # Up
        self.w3 = nn.Linear(intermediate_size, hidden_size, bias=False) # Down

    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))

class TransformerBlock(nn.Module):
    def __init__(self, hidden_size, num_heads, intermediate_size):
        super().__init__()
        self.norm1 = RMSNorm(hidden_size)
        self.attn = CausalSelfAttention(hidden_size, num_heads)
        self.norm2 = RMSNorm(hidden_size)
        self.mlp = SwiGLUMlp(hidden_size, intermediate_size)

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x

class USUFTransformer(nn.Module):
    def __init__(self, vocab_size, hidden_size=128, num_layers=4, num_heads=4, intermediate_size=256, max_seq_len=128):
        super().__init__()
        self.max_seq_len = max_seq_len
        self.token_embeddings = nn.Embedding(vocab_size, hidden_size)
        self.pos_embeddings = nn.Embedding(max_seq_len, hidden_size)
        self.blocks = nn.ModuleList([
            TransformerBlock(hidden_size, num_heads, intermediate_size)
            for _ in range(num_layers)
        ])
        self.norm_final = RMSNorm(hidden_size)
        self.lm_head = nn.Linear(hidden_size, vocab_size, bias=False)
        # مشاركة أوزان المدخل والمخرج (Weight Tying)
        self.token_embeddings.weight = self.lm_head.weight

    def forward(self, idx, targets=None):
        B, T = idx.size()
        pos = torch.arange(0, T, dtype=torch.long, device=idx.device)
        x = self.token_embeddings(idx) + self.pos_embeddings(pos)
        for block in self.blocks:
            x = block(x)
        x = self.norm_final(x)
        logits = self.lm_head(x)

        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1))
        return logits, loss

    @torch.no_grad()
    def generate(self, idx, max_new_tokens=100, temperature=0.8, top_k=20):
        for _ in range(max_new_tokens):
            idx_cond = idx[:, -self.max_seq_len:]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :] / temperature
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float('Inf')
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, next_token), dim=1)
        return idx

# إنشاء النموذج
model = USUFTransformer(vocab_size=vocab_size, hidden_size=128, num_layers=4, num_heads=4).to(device)
total_params = sum(p.numel() for p in model.parameters())
print(f"🧠 تم بناء معمارية USUF-0.01 بإجمالي معايير: {total_params:,} معيار (Parameters)")

# 5. حلقة التدريب (Training Loop)
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=0.01)
batch_size = 16
block_size = 64
epochs = 300

def get_batch(split='train'):
    data = train_data if split == 'train' else val_data
    ix = torch.randint(len(data) - block_size, (batch_size,))
    x = torch.stack([data[i:i+block_size] for i in ix])
    y = torch.stack([data[i+1:i+block_size+1] for i in ix])
    return x.to(device), y.to(device)

print("\n🚀 بدء عملية تدريب النموذج...")
start_time = time.time()

for epoch in range(1, epochs + 1):
    xb, yb = get_batch('train')
    logits, loss = model(xb, yb)
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    optimizer.step()

    if epoch % 50 == 0 or epoch == 1:
        print(f"خطوة [{epoch}/{epochs}] — قيمة الخطأ (Loss): {loss.item():.4f}")

total_time = time.time() - start_time
print(f"✅ اكتمل التدريب بنجاح في {total_time:.2f} ثانية!")

# 6. حفظ الأوزان
torch.save(model.state_dict(), "usuf_model_weights.pt")
print("💾 تم حفظ أوزان النموذج في الملف: usuf_model_weights.pt")

# 7. التوليد والاستنتاج (Inference)
print("\n" + "=" * 60)
print("🎯 اختبار توليد النصوص من النموذج المدرب (USUF Inference):")
print("=" * 60)

test_prompt = "مرحباً بكم في"
context_tokens = torch.tensor([encode(test_prompt)], dtype=torch.long, device=device)
generated_tokens = model.generate(context_tokens, max_new_tokens=120)
generated_text = decode(generated_tokens[0].tolist())

print(f"النص المولّد:\n{generated_text}")
print("=" * 60)
print("🎉 مبارك يا مهندس يوسف الباز، نموذجك الأول تدرب بنجاح ومن الصفر!")
