"""
USUF AI - Tokenizer Training Script (Phase 1 Ready)
Trains a Byte-Level Byte-Pair Encoding (BPE) Tokenizer from scratch on raw text.
Zero external pretrained weights or models.
"""
import os
import sys
import yaml
from pathlib import Path
from typing import List, Optional

try:
    from tokenizers import Tokenizer, normalizers, pre_tokenizers, trainers, models
    from tokenizers.models import BPE
    from tokenizers.normalizers import NFKC
    from tokenizers.pre_tokenizers import ByteLevel, Split
    from tokenizers.trainers import BpeTrainer
except ImportError:
    pass


def load_config(config_path: str = "configs/tokenizer.yaml") -> dict:
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)["tokenizer"]


def build_tokenizer(config: dict):
    """Constructs un-trained Byte-Level BPE tokenizer architecture."""
    # Byte-level BPE guarantees 0% Out-of-Vocabulary (OOV) for any unicode/Arabic character
    tokenizer = Tokenizer(BPE(unk_token=config["special_tokens"]["unk_token"]))

    # Unicode normalization (NFKC)
    tokenizer.normalizer = normalizers.Sequence([
        NFKC()
    ])

    # Pre-tokenization: Byte-level preserves byte-level integrity
    tokenizer.pre_tokenizer = ByteLevel(add_prefix_space=False, trim_offsets=True)
    return tokenizer


def train_tokenizer_from_files(
    file_paths: List[str],
    output_path: str = "configs/tokenizer.json",
    config_path: str = "configs/tokenizer.yaml"
):
    """Trains BPE tokenizer on a list of input text files."""
    config = load_config(config_path)
    tokenizer = build_tokenizer(config)

    special_tokens_list = list(config["special_tokens"].values())
    
    trainer = BpeTrainer(
        vocab_size=config["vocab_size"],
        min_frequency=config["min_frequency"],
        special_tokens=special_tokens_list,
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet()
    )

    print(f"[*] Training USUF-1 BPE Tokenizer on {len(file_paths)} files...")
    print(f"[*] Target vocab size: {config['vocab_size']}")
    tokenizer.train(files=file_paths, trainer=trainer)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    tokenizer.save(output_path)
    print(f"[✓] USUF Tokenizer successfully trained and saved to: {output_path}")
    return tokenizer


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Train USUF AI Tokenizer from scratch.")
    parser.add_argument("--data_files", nargs="+", help="Paths to text files for training.")
    parser.add_argument("--output", default="configs/tokenizer.json", help="Path to save tokenizer.json.")
    parser.add_argument("--config", default="configs/tokenizer.yaml", help="Path to tokenizer config.")
    args = parser.parse_args()

    if not args.data_files:
        print("[!] No input data files specified. For Phase 0 testing, tokenizer foundation is configured.")
        print("    Usage in Phase 1: python tokenizer/train_tokenizer.py --data_files data/raw/corpus.txt")
        sys.exit(0)

    train_tokenizer_from_files(args.data_files, args.output, args.config)
