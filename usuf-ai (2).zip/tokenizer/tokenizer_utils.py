"""
USUF AI - Tokenizer Utilities
Provides encoding, decoding, token counting, and special token handling.
Strictly zero-pretrained: relies only on local trained tokenizer.json.
"""
import os
import json
from typing import List, Dict, Any, Optional

try:
    from tokenizers import Tokenizer
except ImportError:
    Tokenizer = None  # Handled gracefully if running in light test mode


def load_tokenizer(tokenizer_path: str = "configs/tokenizer.json"):
    """Loads trained tokenizers.Tokenizer from file."""
    if Tokenizer is None:
        raise ImportError("HuggingFace 'tokenizers' library is required. Install via pip install tokenizers.")
    if not os.path.exists(tokenizer_path):
        raise FileNotFoundError(
            f"Tokenizer file not found at '{tokenizer_path}'. "
            f"Run 'python tokenizer/train_tokenizer.py' first during Phase 1."
        )
    return Tokenizer.from_file(tokenizer_path)


def save_tokenizer(tokenizer, save_path: str = "configs/tokenizer.json"):
    """Saves tokenizer instance to JSON file."""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    tokenizer.save(save_path)


def encode_text(tokenizer, text: str, add_special_tokens: bool = True) -> List[int]:
    """Encodes a string into token IDs."""
    encoded = tokenizer.encode(text)
    ids = encoded.ids
    return ids


def decode_tokens(tokenizer, token_ids: List[int], skip_special_tokens: bool = True) -> str:
    """Decodes token IDs back into string."""
    return tokenizer.decode(token_ids, skip_special_tokens=skip_special_tokens)


def get_vocab_stats(tokenizer) -> Dict[str, Any]:
    """Returns vocabulary size and basic structural stats."""
    vocab = tokenizer.get_vocab()
    return {
        "vocab_size": len(vocab),
        "pad_token_id": vocab.get("<pad>"),
        "bos_token_id": vocab.get("<s>"),
        "eos_token_id": vocab.get("</s>"),
        "unk_token_id": vocab.get("<unk>"),
    }
